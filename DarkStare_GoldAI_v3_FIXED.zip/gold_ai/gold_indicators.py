"""
gold_indicators.py — Complete indicator suite for XAUUSD

Calculates ALL moving averages (SMA/EMA/WMA: 9,15,20,21,50,80,200),
RSI, MACD, Bollinger Bands, ATR, Stochastic, Momentum, Volume,
Pivot levels, and MA interaction analysis (bounces, crosses, convergence).
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List

import config


@dataclass
class GoldIndicators:
    # ── Moving Averages ──────────────────────────────
    sma9: float = 0; sma15: float = 0; sma20: float = 0
    sma50: float = 0; sma80: float = 0; sma200: float = 0
    ema9: float = 0; ema15: float = 0; ema21: float = 0
    ema50: float = 0; ema80: float = 0; ema200: float = 0
    wma9: float = 0; wma21: float = 0; wma55: float = 0
    # ── Oscillators ──────────────────────────────────
    rsi: float = 50
    macd: float = 0; macd_sig: float = 0; macd_hist: float = 0
    stoch_k: float = 50; stoch_d: float = 50
    rsi_prev: float = 50   # previous bar RSI for divergence
    # ── Volatility ───────────────────────────────────
    atr: float = 0; atr_pct: float = 0
    bb_upper: float = 0; bb_mid: float = 0; bb_lower: float = 0; bb_width: float = 0
    # ── Momentum ─────────────────────────────────────
    mom5: float = 0; mom10: float = 0; mom20: float = 0
    vol_ratio: float = 1.0    # current vol vs 20-bar avg
    # ── Price ────────────────────────────────────────
    close: float = 0; high: float = 0; low: float = 0; open_: float = 0
    prev_close: float = 0
    # ── Pivot Levels ─────────────────────────────────
    pivot: float = 0
    r1: float = 0; r2: float = 0; r3: float = 0
    s1: float = 0; s2: float = 0; s3: float = 0
    # ── MA Analysis ──────────────────────────────────
    ma_trend: str = "NEUTRAL"      # BULL / BEAR / NEUTRAL
    ma_stack_bull: bool = False    # all MAs stacked bullish
    ma_stack_bear: bool = False    # all MAs stacked bearish
    price_vs_ema200: str = "ABOVE" # ABOVE / BELOW
    # ── MA Crossovers (detected this bar) ────────────
    cross_9_15_bull: bool = False
    cross_9_15_bear: bool = False
    cross_9_21_bull: bool = False
    cross_9_21_bear: bool = False
    cross_50_200_bull: bool = False  # golden cross
    cross_50_200_bear: bool = False  # death cross
    # ── MA Bounce Detection ──────────────────────────
    bounce_ema9: bool = False
    bounce_ema21: bool = False
    bounce_ema50: bool = False
    bounce_ema80: bool = False
    bounce_ema200: bool = False
    bounce_sma80: bool = False
    bounce_sma200: bool = False
    bounce_direction: str = "NONE"   # BULL / BEAR
    # ── MA Convergence / Compression ────────────────
    mas_converging: bool = False    # MAs squeezing together
    mas_diverging: bool = False     # MAs spreading apart
    # ── Gold-specific ────────────────────────────────
    above_key_level: bool = False   # above 2000, 2300, 2500 etc
    near_key_level: float = 0       # nearest round number
    # ── Trend ────────────────────────────────────────
    trend_strength: float = 0.0    # 0-1
    hh: bool = False; hl: bool = False
    lh: bool = False; ll: bool = False


def _wma(series: pd.Series, n: int) -> pd.Series:
    weights = np.arange(1, n + 1)
    return series.rolling(n).apply(lambda x: np.dot(x, weights) / weights.sum(), raw=True)


def calc(df: pd.DataFrame) -> GoldIndicators:
    """Calculate all indicators for a given OHLCV dataframe."""
    ind = GoldIndicators()
    c = df["close"]; h = df["high"]; l = df["low"]; o = df["open"]
    vol = df.get("volume", pd.Series(np.ones(len(df))))
    n = len(df)
    if n < 10:
        return ind

    # ── SMAs ─────────────────────────────────────────
    ind.sma9   = c.rolling(9).mean().iloc[-1]
    ind.sma15  = c.rolling(15).mean().iloc[-1]
    ind.sma20  = c.rolling(20).mean().iloc[-1]
    ind.sma50  = c.rolling(50).mean().iloc[-1]  if n>=50  else c.mean()
    ind.sma80  = c.rolling(80).mean().iloc[-1]  if n>=80  else c.mean()
    ind.sma200 = c.rolling(200).mean().iloc[-1] if n>=200 else c.mean()

    # ── EMAs ─────────────────────────────────────────
    ind.ema9   = c.ewm(span=9,   adjust=False).mean().iloc[-1]
    ind.ema15  = c.ewm(span=15,  adjust=False).mean().iloc[-1]
    ind.ema21  = c.ewm(span=21,  adjust=False).mean().iloc[-1]
    ind.ema50  = c.ewm(span=50,  adjust=False).mean().iloc[-1]
    ind.ema80  = c.ewm(span=80,  adjust=False).mean().iloc[-1]
    ind.ema200 = c.ewm(span=200, adjust=False).mean().iloc[-1]

    # WMAs
    ind.wma9  = _wma(c, 9).iloc[-1]
    ind.wma21 = _wma(c, 21).iloc[-1]
    ind.wma55 = _wma(c, 55).iloc[-1] if n>=55 else c.mean()

    # ── RSI(14) ──────────────────────────────────────
    delta = c.diff()
    gain  = delta.clip(lower=0).rolling(14).mean()
    loss  = (-delta.clip(upper=0)).rolling(14).mean()
    rs    = gain / loss.replace(0, 1e-9)
    rsi_s = 100 - 100 / (1 + rs)
    ind.rsi      = round(rsi_s.iloc[-1], 2)
    ind.rsi_prev = round(rsi_s.iloc[-2], 2) if n >= 2 else ind.rsi

    # ── MACD(12,26,9) ────────────────────────────────
    ema12 = c.ewm(span=12, adjust=False).mean()
    ema26 = c.ewm(span=26, adjust=False).mean()
    ml    = ema12 - ema26
    sig   = ml.ewm(span=9, adjust=False).mean()
    hist  = ml - sig
    ind.macd     = round(ml.iloc[-1],   4)
    ind.macd_sig = round(sig.iloc[-1],  4)
    ind.macd_hist= round(hist.iloc[-1], 4)

    # ── Bollinger Bands(20,2) ─────────────────────────
    ma20  = c.rolling(20).mean()
    std20 = c.rolling(20).std()
    ind.bb_upper = round((ma20 + 2*std20).iloc[-1], 3)
    ind.bb_mid   = round(ma20.iloc[-1], 3)
    ind.bb_lower = round((ma20 - 2*std20).iloc[-1], 3)
    ind.bb_width = round((ind.bb_upper - ind.bb_lower) / max(ind.bb_mid,1), 5)

    # ── ATR(14) ──────────────────────────────────────
    tr  = pd.concat([h-l, (h-c.shift()).abs(), (l-c.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(14).mean()
    ind.atr     = round(atr.iloc[-1], 3)
    ind.atr_pct = round(ind.atr / max(c.iloc[-1], 1) * 100, 4)

    # ── Stochastic(14,3) ─────────────────────────────
    lo14 = l.rolling(14).min(); hi14 = h.rolling(14).max()
    k_s  = 100*(c-lo14)/(hi14-lo14).replace(0,1e-9)
    ind.stoch_k = round(k_s.iloc[-1], 2)
    ind.stoch_d = round(k_s.rolling(3).mean().iloc[-1], 2)

    # ── Momentum ─────────────────────────────────────
    ind.mom5  = round(c.iloc[-1] - c.iloc[-6]  if n>=6  else 0, 3)
    ind.mom10 = round(c.iloc[-1] - c.iloc[-11] if n>=11 else 0, 3)
    ind.mom20 = round(c.iloc[-1] - c.iloc[-21] if n>=21 else 0, 3)

    # Volume ratio
    vol_avg = vol.rolling(20).mean().iloc[-1]
    ind.vol_ratio = round(vol.iloc[-1] / max(vol_avg, 1e-9), 2)

    # ── Price ────────────────────────────────────────
    ind.close     = round(c.iloc[-1], 3)
    ind.high      = round(h.iloc[-1], 3)
    ind.low       = round(l.iloc[-1], 3)
    ind.open_     = round(o.iloc[-1], 3)
    ind.prev_close= round(c.iloc[-2], 3) if n>=2 else ind.close

    # ── Pivots (calculated from previous bar H/L/C) ──
    ph = h.iloc[-2]; pl = l.iloc[-2]; pc = c.iloc[-2]
    pv = (ph+pl+pc)/3
    ind.pivot = round(pv, 3)
    ind.r1 = round(2*pv - pl, 3);  ind.s1 = round(2*pv - ph, 3)
    ind.r2 = round(pv+(ph-pl), 3); ind.s2 = round(pv-(ph-pl), 3)
    ind.r3 = round(ph+2*(pv-pl),3);ind.s3 = round(pl-2*(ph-pv),3)

    # ── MA Trend Analysis ────────────────────────────
    p = ind.close
    bull_count = sum([
        p > ind.ema9, p > ind.ema21, p > ind.ema50, p > ind.ema200,
        ind.ema9 > ind.ema21, ind.ema21 > ind.ema50, ind.ema50 > ind.ema200
    ])
    bear_count = sum([
        p < ind.ema9, p < ind.ema21, p < ind.ema50, p < ind.ema200,
        ind.ema9 < ind.ema21, ind.ema21 < ind.ema50, ind.ema50 < ind.ema200
    ])
    if bull_count >= 6:   ind.ma_trend = "BULL"
    elif bear_count >= 6: ind.ma_trend = "BEAR"
    else:                 ind.ma_trend = "NEUTRAL"

    ind.ma_stack_bull = (ind.ema9>ind.ema21>ind.ema50>ind.ema200 and p>ind.ema9)
    ind.ma_stack_bear = (ind.ema9<ind.ema21<ind.ema50<ind.ema200 and p<ind.ema9)
    ind.price_vs_ema200 = "ABOVE" if p > ind.ema200 else "BELOW"

    # ── MA Crossovers ────────────────────────────────
    if n >= 2:
        prev_e9  = c.ewm(span=9,  adjust=False).mean().iloc[-2]
        prev_e15 = c.ewm(span=15, adjust=False).mean().iloc[-2]
        prev_e21 = c.ewm(span=21, adjust=False).mean().iloc[-2]
        prev_e50 = c.ewm(span=50, adjust=False).mean().iloc[-2]
        prev_e200= c.ewm(span=200,adjust=False).mean().iloc[-2]

        ind.cross_9_15_bull  = prev_e9 <= prev_e15 and ind.ema9 > ind.ema15
        ind.cross_9_15_bear  = prev_e9 >= prev_e15 and ind.ema9 < ind.ema15
        ind.cross_9_21_bull  = prev_e9 <= prev_e21 and ind.ema9 > ind.ema21
        ind.cross_9_21_bear  = prev_e9 >= prev_e21 and ind.ema9 < ind.ema21
        ind.cross_50_200_bull= prev_e50<=prev_e200  and ind.ema50>ind.ema200
        ind.cross_50_200_bear= prev_e50>=prev_e200  and ind.ema50<ind.ema200

    # ── MA Bounce Detection ──────────────────────────
    prev_l = l.iloc[-2]; prev_h = h.iloc[-2]
    atr_v  = ind.atr
    tol    = atr_v * 0.35   # within 35% of ATR = "touching" the MA

    def _near(level): return abs(p - level) < tol or (prev_l < level < p) or (prev_h > level > p)

    ind.bounce_ema9  = _near(ind.ema9)
    ind.bounce_ema21 = _near(ind.ema21)
    ind.bounce_ema50 = _near(ind.ema50)
    ind.bounce_ema80 = _near(ind.ema80)
    ind.bounce_ema200= _near(ind.ema200)
    ind.bounce_sma80 = _near(ind.sma80)
    ind.bounce_sma200= _near(ind.sma200)

    any_bounce = any([ind.bounce_ema21, ind.bounce_ema50,
                      ind.bounce_ema80, ind.bounce_ema200, ind.bounce_sma80])
    if any_bounce:
        ind.bounce_direction = "BULL" if c.iloc[-1]>c.iloc[-2] else "BEAR"

    # ── MA Convergence ───────────────────────────────
    spread_now  = max(ind.ema9, ind.ema21, ind.ema50) - min(ind.ema9, ind.ema21, ind.ema50)
    if n >= 10:
        ema9_10  = c.ewm(span=9,  adjust=False).mean().iloc[-10]
        ema21_10 = c.ewm(span=21, adjust=False).mean().iloc[-10]
        ema50_10 = c.ewm(span=50, adjust=False).mean().iloc[-10]
        spread_10 = max(ema9_10,ema21_10,ema50_10)-min(ema9_10,ema21_10,ema50_10)
        ind.mas_converging = spread_now < spread_10 * 0.6
        ind.mas_diverging  = spread_now > spread_10 * 1.5

    # ── Gold Key Levels (psychological) ──────────────
    key_levels = [1800,1900,2000,2050,2100,2150,2200,2300,
                  2400,2500,2600,2700,2800,2900,3000,3100,3200,3300,3400]
    nearest = min(key_levels, key=lambda x: abs(x-p))
    ind.near_key_level  = float(nearest)
    ind.above_key_level = p > nearest

    # ── Market Structure ─────────────────────────────
    if n >= 30:
        win = 5
        s_highs = [(i, h.iloc[i]) for i in range(win, n-win)
                   if h.iloc[i]==h.iloc[i-win:i+win+1].max()]
        s_lows  = [(i, l.iloc[i]) for i in range(win, n-win)
                   if l.iloc[i]==l.iloc[i-win:i+win+1].min()]
        if len(s_highs)>=2:
            ind.hh = s_highs[-1][1] > s_highs[-2][1]
            ind.lh = s_highs[-1][1] < s_highs[-2][1]
        if len(s_lows)>=2:
            ind.hl = s_lows[-1][1] > s_lows[-2][1]
            ind.ll = s_lows[-1][1] < s_lows[-2][1]

    if ind.hh and ind.hl: ind.trend_strength = 0.85
    elif ind.lh and ind.ll: ind.trend_strength = -0.85
    else: ind.trend_strength = 0.0

    return ind


def to_dict(ind: GoldIndicators) -> dict:
    """Convert to dict for logging/storage."""
    return {k: v for k, v in ind.__dict__.items()}
