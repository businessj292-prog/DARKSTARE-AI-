"""
gold_ai_engine.py — Gold Analysis & Decision Engine

Combines ALL timeframes, ALL indicators, ALL patterns, news, memory,
sequence learning, and discovered strategies into one trade decision.
"""

import config
import sessions
import gold_brain as brain
import gold_news
from gold_indicators import GoldIndicators


def _w(name):
    """Get current learned weight."""
    return brain.load_wgt().get(name, config.STRATEGY_WEIGHTS.get(name, 10))


# ─────────────────────────────────────────────
#  INDIVIDUAL SCORERS
# ─────────────────────────────────────────────

def _score_ma_alignment(ind: GoldIndicators, tf: str):
    tf_m={"D1":1.0,"H4":0.95,"H1":0.85,"M15":0.7,"M5":0.5,"M1":0.3}
    m=tf_m.get(tf,0.6); w=_w("ma_alignment"); bull=bear=0; note=""
    if ind.ma_stack_bull:
        bull=w*m; note=f"MA full bull stack ({tf})"
    elif ind.ma_stack_bear:
        bear=w*m; note=f"MA full bear stack ({tf})"
    elif ind.ma_trend=="BULL":
        bull=w*0.55*m; note=f"MA partial bull ({tf})"
    elif ind.ma_trend=="BEAR":
        bear=w*0.55*m; note=f"MA partial bear ({tf})"
    # Price vs EMA200 (macro)
    if ind.price_vs_ema200=="ABOVE": bull+=w*0.3*m
    else:                            bear+=w*0.3*m
    return bull, bear, note


def _score_ma_cross(ind: GoldIndicators):
    w=_w("ma_crossover"); bull=bear=0; note=""
    if ind.cross_50_200_bull:
        bull=w*2.0; note="🌟 GOLDEN CROSS — major bull signal"
    elif ind.cross_50_200_bear:
        bear=w*2.0; note="💀 DEATH CROSS — major bear signal"
    elif ind.cross_9_21_bull:
        bull=w*0.9; note="EMA9 x EMA21 bull cross"
    elif ind.cross_9_21_bear:
        bear=w*0.9; note="EMA9 x EMA21 bear cross"
    elif ind.cross_9_15_bull:
        bull=w*0.7; note="EMA9 x EMA15 bull cross"
    elif ind.cross_9_15_bear:
        bear=w*0.7; note="EMA9 x EMA15 bear cross"
    return bull, bear, note


def _score_ma_bounce(ind: GoldIndicators):
    w=_w("ma_bounce"); bull=bear=0; note=""
    bounces={
        "bounce_ema200": (w*1.0, "Bounce off EMA200 — MAJOR level"),
        "bounce_sma200": (w*1.0, "Bounce off SMA200 — MAJOR level"),
        "bounce_sma80":  (w*0.85,"Bounce off SMA80 — institutional level"),
        "bounce_ema80":  (w*0.80,"Bounce off EMA80"),
        "bounce_ema50":  (w*0.70,"Bounce off EMA50"),
        "bounce_ema21":  (w*0.60,"Bounce off EMA21"),
        "bounce_ema9":   (w*0.40,"Bounce off EMA9"),
    }
    for attr,(score,n) in bounces.items():
        if getattr(ind,attr,False):
            if ind.bounce_direction=="BULL": bull=score; note=n; break
            elif ind.bounce_direction=="BEAR": bear=score; note=n; break
    # Pullback in trend
    if ind.ma_stack_bull and ind.bounce_ema21:
        bull+=w*0.4; note="Pullback to EMA21 in bull stack — buy dip"
    if ind.ma_stack_bear and ind.bounce_ema21:
        bear+=w*0.4; note="Rally to EMA21 in bear stack — sell rally"
    return bull, bear, note


def _score_rsi(ind: GoldIndicators):
    w=_w("rsi"); r=ind.rsi; pr=ind.rsi_prev
    bull=bear=0; note=""
    # Hidden divergence: price HH but RSI LH = bearish div
    # Price LL but RSI HL = bullish divergence (simplified)
    if r<=22:   bull=w*1.1; note=f"RSI extreme OS ({r:.1f}) — reversal high prob"
    elif r<=32: bull=w*0.9; note=f"RSI oversold ({r:.1f})"
    elif r<=45: bull=w*0.4; note=f"RSI bearish zone ({r:.1f})"
    elif r>=78: bear=w*1.1; note=f"RSI extreme OB ({r:.1f}) — reversal high prob"
    elif r>=68: bear=w*0.9; note=f"RSI overbought ({r:.1f})"
    elif r>=55: bull=w*0.4; note=f"RSI bullish zone ({r:.1f})"
    # RSI direction change (momentum shift)
    if pr<=30 and r>pr+5: bull+=w*0.3; note+=f" ↗ RSI turning up"
    if pr>=70 and r<pr-5: bear+=w*0.3; note+=f" ↘ RSI turning down"
    return bull, bear, note


def _score_macd(ind: GoldIndicators):
    w=_w("macd"); m=ind.macd; s=ind.macd_sig; h=ind.macd_hist; bull=bear=0; note=""
    if m>s and h>0 and m>0:   bull=w;     note="MACD bullish cross above zero"
    elif m>s and h>0:          bull=w*0.7; note="MACD bullish cross below zero"
    elif m<s and h<0 and m<0: bear=w;     note="MACD bearish cross below zero"
    elif m<s and h<0:          bear=w*0.7; note="MACD bearish cross above zero"
    elif h>0:                  bull=w*0.3; note="MACD hist positive"
    else:                      bear=w*0.3; note="MACD hist negative"
    return bull, bear, note


def _score_bb(ind: GoldIndicators):
    w=_w("bollinger"); p=ind.close; bull=bear=0; note=""
    sq=" | BB SQUEEZE!" if ind.bb_width<0.01 else ""
    if p<=ind.bb_lower:   bull=w;     note=f"Price at BB Lower — bounce zone{sq}"
    elif p>=ind.bb_upper: bear=w;     note=f"Price at BB Upper — rejection zone{sq}"
    elif p>ind.bb_mid:    bull=w*0.3; note=f"Above BB mid{sq}"
    else:                 bear=w*0.3; note=f"Below BB mid{sq}"
    return bull, bear, note


def _score_stoch(ind: GoldIndicators):
    w=_w("stochastic"); k=ind.stoch_k; d=ind.stoch_d; bull=bear=0; note=""
    if k<20 and d<20 and k>d:  bull=w;     note=f"Stoch extreme OS + cross ({k:.0f}/{d:.0f})"
    elif k<30:                  bull=w*0.5; note=f"Stoch oversold ({k:.0f})"
    elif k>80 and d>80 and k<d:bear=w;     note=f"Stoch extreme OB + cross ({k:.0f}/{d:.0f})"
    elif k>70:                  bear=w*0.5; note=f"Stoch overbought ({k:.0f})"
    elif k>50 and k>d:          bull=w*0.25;note=f"Stoch mid-bull"
    elif k<50 and k<d:          bear=w*0.25;note=f"Stoch mid-bear"
    return bull, bear, note


def _score_momentum(ind: GoldIndicators):
    w=_w("atr_momentum"); bull=bear=0; note=""
    pos_mom=(ind.mom5>0)+(ind.mom10>0)+(ind.mom20>0)
    neg_mom=(ind.mom5<0)+(ind.mom10<0)+(ind.mom20<0)
    vr=ind.vol_ratio; vol_note=f" vol×{vr:.1f}" if vr>1.3 else ""
    if pos_mom>=3: bull=w*(min(vr,2)/2);   note=f"Strong positive momentum{vol_note}"
    elif pos_mom==2:bull=w*0.5*(min(vr,2)/2);note=f"Moderate momentum{vol_note}"
    elif neg_mom>=3:bear=w*(min(vr,2)/2);   note=f"Strong negative momentum{vol_note}"
    elif neg_mom==2:bear=w*0.5*(min(vr,2)/2)
    return bull, bear, note


def _score_structure(ind: GoldIndicators, tf: str):
    w=_w("structure"); bull=bear=0; note=""
    tf_m={"D1":1.0,"H4":0.9,"H1":0.8,"M15":0.6,"M5":0.4,"M1":0.2}
    m=tf_m.get(tf,0.5)
    if ind.hh and ind.hl:
        bull=w*m*0.9; note=f"HH/HL structure ({tf}) — confirmed uptrend"
    elif ind.lh and ind.ll:
        bear=w*m*0.9; note=f"LH/LL structure ({tf}) — confirmed downtrend"
    return bull, bear, note


def _score_session():
    w=_w("session_bias"); mult=sessions.multiplier(); bull=bear=0
    can,reason=sessions.is_tradeable()
    kz=sessions.is_gold_killzone()
    note=sessions.summary()
    if kz:
        bull+=w*0.3; note+=" 🔥GOLD KILLZONE — high probability zone"
    if can:
        s_key=sessions.current_key()
        if s_key in ["overlap","london"]: bull+=w*mult*0.4
    return bull, bear, note


def _score_support_resist(ind: GoldIndicators):
    w=_w("support_resist"); p=ind.close; atr=ind.atr; bull=bear=0; note=""
    levels=brain.get_strong_levels(p, atr)
    sup=levels["support"]; res=levels["resistance"]
    # Near remembered support
    if sup:
        d=abs(p-sup[0])/atr
        if d<0.6: bull=w*(1-d/0.6); note=f"Near memorised support {sup[0]:.1f}"
    if res:
        d=abs(p-res[0])/atr
        if d<0.6: bear=w*(1-d/0.6); note=f"Near memorised resistance {res[0]:.1f}"
    # Pivots
    if p>ind.r1: bull+=w*0.5; note=f"Above R1={ind.r1:.1f}"
    elif p<ind.s1:bear+=w*0.5; note=f"Below S1={ind.s1:.1f}"
    elif abs(p-ind.s1)<atr*0.3: bull+=w*0.35; note=f"Near S1 support {ind.s1:.1f}"
    elif abs(p-ind.r1)<atr*0.3: bear+=w*0.35; note=f"Near R1 resistance {ind.r1:.1f}"
    # Key gold levels
    key=ind.near_key_level
    if key>0 and abs(p-key)<atr*0.5:
        if p>key: bull+=w*0.2; note+=f" | Above key level {key:.0f}"
        else:     bear+=w*0.2; note+=f" | Below key level {key:.0f}"
    return bull, bear, note


def _score_patterns(pat_data: dict):
    w=_w("chart_pattern")+_w("candlestick"); bull=bear=0; note=""
    bs=pat_data.get("bull_score",0); br=pat_data.get("bear_score",0)
    top=pat_data.get("top","none"); td=pat_data.get("top_dir","NEUTRAL")
    tn=pat_data.get("top_note","")
    # Adjust by historical win rate
    wr=brain.load_mem().get("pattern_stats",{}).get(top,{})
    pw=wr.get("wins",0); pl=wr.get("losses",0); pt=pw+pl
    adj=(pw/pt-0.5)*2 if pt>=3 else 0
    # Trap patterns get extra weight
    trap=pat_data.get("trap_detected",False)
    trap_boost=1.4 if trap else 1.0
    if td=="BULL": bull=w*bs*(1+adj*0.3)*trap_boost; note=tn
    elif td=="BEAR":bear=w*br*(1+adj*0.3)*trap_boost; note=tn
    return bull, bear, note


def _score_trap(pat_data: dict):
    w=_w("market_trap"); bull=bear=0; note=""
    if not pat_data.get("trap_detected"): return bull, bear, note
    for p in pat_data.get("all",[]):
        if p.get("cat")=="trap":
            if p["d"]=="BULL": bull=w*p["s"]; note=f"⚠ TRAP: {p['note']}"
            elif p["d"]=="BEAR":bear=w*p["s"]; note=f"⚠ TRAP: {p['note']}"
            break
    return bull, bear, note


def _score_news():
    w=_w("gold_sentiment")
    try:
        nb,nr,nn=gold_news.get_news_weight()
        return nb*(w/10), nr*(w/10), nn
    except Exception:
        return 0,0,"📰 News unavailable"


# ─────────────────────────────────────────────
#  MAIN ANALYSIS FUNCTION
# ─────────────────────────────────────────────

def analyse(tf_indicators: dict, tf_patterns: dict,
            primary_tokens: list[str]) -> dict:
    """
    Multi-timeframe gold analysis.
    tf_indicators: {tf: GoldIndicators}
    tf_patterns:   {tf: pattern_dict}
    Returns full decision dict.
    """
    total_bull = 0.0
    total_bear = 0.0
    reasons    = []
    active_strats = []

    # ── Per-timeframe scoring ────────────────────────
    for tf, ind in tf_indicators.items():
        b,r,n = _score_ma_alignment(ind, tf)
        total_bull+=b; total_bear+=r
        if n: reasons.append(n); active_strats.append("ma_alignment")

        if tf==config.PRIMARY_TF:
            for fn, name in [
                (_score_ma_cross,  "ma_crossover"),
                (_score_ma_bounce, "ma_bounce"),
                (_score_rsi,       "rsi"),
                (_score_macd,      "macd"),
                (_score_bb,        "bollinger"),
                (_score_stoch,     "stochastic"),
                (_score_momentum,  "atr_momentum"),
                (_score_structure, "structure"),
            ]:
                if name=="structure":
                    b,r,n=fn(ind, tf)
                else:
                    b,r,n=fn(ind)
                total_bull+=b; total_bear+=r
                if n: reasons.append(n); active_strats.append(name)

        elif tf in [config.TREND_TF, config.MACRO_TF]:
            # Also score structure on higher TFs
            b,r,n=_score_structure(ind, tf)
            total_bull+=b; total_bear+=r
            if n: reasons.append(n)
            # MA alignment on H4/D1
            b,r,n=_score_ma_cross(ind)
            total_bull+=b; total_bear+=r
            if n: reasons.append(n)

    # ── Patterns (primary TF) ────────────────────────
    if config.PRIMARY_TF in tf_patterns:
        pd_=tf_patterns[config.PRIMARY_TF]
        b,r,n=_score_patterns(pd_);active_strats.append("candlestick")
        total_bull+=b; total_bear+=r
        if n: reasons.append(n)
        b,r,n=_score_trap(pd_); active_strats.append("market_trap")
        total_bull+=b; total_bear+=r
        if n: reasons.append(n)

    # ── Support/Resistance ───────────────────────────
    if config.PRIMARY_TF in tf_indicators:
        b,r,n=_score_support_resist(tf_indicators[config.PRIMARY_TF])
        total_bull+=b; total_bear+=r
        if n: reasons.append(n); active_strats.append("support_resist")

    # ── Session ──────────────────────────────────────
    b,r,n=_score_session(); active_strats.append("session_bias")
    total_bull+=b; total_bear+=r
    reasons.append(n)

    # ── News ─────────────────────────────────────────
    b,r,n=_score_news(); active_strats.append("gold_sentiment")
    total_bull+=b; total_bear+=r
    if n: reasons.append(n)

    # ── Sequence boost ───────────────────────────────
    dominant=(lambda: "BUY" if total_bull>=total_bear else "SELL")()
    seq_boost, seq_note = brain.get_seq_boost(primary_tokens, dominant)
    if seq_note:
        reasons.append(f"SeqLearner: {seq_note}")

    # ── Strategy boost ───────────────────────────────
    s_boost, s_name = brain.get_strategy_boost(primary_tokens, dominant)
    if s_boost>0:
        if dominant=="BUY":  total_bull+=s_boost
        else:                total_bear+=s_boost
        reasons.append(f"🎯 Strategy match: «{s_name}» (+{s_boost:.1f}pts)")
        active_strats.append("discovered_strategy")

    # ── Confidence ───────────────────────────────────
    dom_s = total_bull if dominant=="BUY" else total_bear
    opp_s = total_bear if dominant=="BUY" else total_bull
    raw   = dom_s/max(dom_s+opp_s,1)*100
    conf  = min(100, int(raw))
    # Apply sequence boost to confidence
    conf  = min(100, int(conf * seq_boost))

    # ── SL/TP (learned per symbol) ───────────────────
    sl_m, tp_m = brain.get_atr_tune()
    ind_p = tf_indicators.get(config.PRIMARY_TF) or list(tf_indicators.values())[0]
    price = ind_p.close; atr = ind_p.atr

    if dominant=="BUY":
        sl=round(price - atr*sl_m, 3); tp=round(price + atr*tp_m, 3)
    else:
        sl=round(price + atr*sl_m, 3); tp=round(price - atr*tp_m, 3)

    sl_d=abs(price-sl); tp_d=abs(price-tp)
    rr=round(tp_d/sl_d,2) if sl_d>0 else 0

    # ── Session gate ─────────────────────────────────
    can_trade, _ = sessions.is_tradeable()

    action="HOLD"
    if (conf>=config.MIN_CONFIDENCE and rr>=config.MIN_RR and can_trade):
        action=dominant

    # Bias label
    rat=total_bull/max(total_bear,0.01)
    bias="BULLISH" if rat>1.25 else ("BEARISH" if rat<0.8 else "NEUTRAL")

    # Remember key levels
    brain.remember_level(ind_p.r1, "resistance")
    brain.remember_level(ind_p.s1, "support")
    brain.remember_level(ind_p.near_key_level, "key_psychological")

    return {
        "action":action,"bias":bias,"confidence":conf,
        "bull_score":round(total_bull,2),"bear_score":round(total_bear,2),
        "entry":round(price,3),"sl":sl,"tp":tp,"rr":rr,"atr":round(atr,3),
        "sl_mult":sl_m,"tp_mult":tp_m,
        "reasons":list(dict.fromkeys(reasons))[:12],
        "active_strats":list(set(active_strats)),
        "can_trade":can_trade,
        "tokens":primary_tokens,
        "price":round(price,3),
    }
