# ═══════════════════════════════════════════════════════════════
#   DARKSTARE GOLD AI — Master Configuration
#   Laser-focused on XAUUSD | Self-Learning | 24/7 | EAT
# ═══════════════════════════════════════════════════════════════

# ── MT5 Connection (0 = use active terminal login) ─────────────
MT5_LOGIN    = 0
MT5_PASSWORD = ""
MT5_SERVER   = ""

# ── Gold Symbol Variants (auto-resolved) ──────────────────────
GOLD_VARIANTS = [
    "XAUUSD", "XAUUSDm", "XAUUSD.", "GOLD", "GOLDm",
    "XAU/USD", "XAUUSD+", "XAUUSD_i", "XAUUSDpro"
]

# ── Timeframes to analyse (ALL of them for full picture) ───────
TIMEFRAMES   = ["M1", "M5", "M15", "H1", "H4", "D1"]
PRIMARY_TF   = "H1"    # main decision timeframe
TREND_TF     = "H4"    # trend confirmation
MACRO_TF     = "D1"    # macro bias
ENTRY_TF     = "M15"   # fine-tune entry
SCALP_TF     = "M5"    # micro pattern detection
CANDLES      = 300     # bars per timeframe

# ── Moving Averages (the full suite) ──────────────────────────
# All MAs calculated on every timeframe
SMA_PERIODS  = [9, 15, 20, 50, 80, 200]      # Simple MAs
EMA_PERIODS  = [9, 15, 21, 50, 80, 200]      # Exponential MAs
WMA_PERIODS  = [9, 21, 55]                   # Weighted MAs
# Key MAs for bounce/reversal/continuation detection:
# 9  EMA  — ultra-fast momentum / micro trend
# 15 EMA  — short-term trend filter
# 21 EMA  — key dynamic support/resistance
# 50 EMA  — mid-term trend
# 80 SMA  — institutional level (less common, highly respected)
# 200 EMA — macro trend / "the line in the sand"

# ── EAT Sessions (hours, no leading zeros) ────────────────────
EAT_SESSIONS = {
    "asian":   (2,  10, "Asian / Tokyo Session",   0.65),
    "london":  (10, 18, "London Session",           1.0),
    "newyork": (15, 23, "New York Session",         1.0),
    "overlap": (15, 18, "London/NY Overlap",        1.35),
    "dead":    (23,  2, "Dead Zone",                0.15),
}
TRADE_SESSIONS = ["london", "newyork", "overlap"]
# Gold also has an early London open spike at 10:00–11:00 EAT
GOLD_KILLZONE = (10, 12)    # EAT hours — high-probability gold moves

# ── Risk Management ────────────────────────────────────────────
BASE_RISK_PCT        = 1.0    # base % of balance per trade
MAX_RISK_PCT         = 2.5    # max % (for high-confidence trades)
MIN_CONFIDENCE       = 60     # min score to trade
HIGH_CONFIDENCE      = 78     # threshold to scale up lot size
VERY_HIGH_CONFIDENCE = 88     # threshold to maximise lot size
MIN_RR               = 1.5
MAX_SPREAD_POINTS    = 500   # Gold spreads can be 50-300pts — never skip gold for spread
MAX_OPEN_TRADES      = 5      # max gold positions simultaneously

# ── Lot Scaling by Confidence ─────────────────────────────────
# Confidence 60-77: BASE_RISK_PCT
# Confidence 78-87: BASE_RISK_PCT × 1.5
# Confidence 88+:   BASE_RISK_PCT × 2.0 (capped at MAX_RISK_PCT)
LOT_SCALE_MID  = 1.5
LOT_SCALE_HIGH = 2.0

# ── SL/TP (ATR-based, self-tuned by AI) ───────────────────────
ATR_SL_MULT  = 1.5
ATR_TP_MULT  = 2.5
ATR_PERIOD   = 14

# ── Trailing Stop ─────────────────────────────────────────────
TRAIL_ENABLE           = True
TRAIL_ATR_MULT         = 1.0    # trail distance = ATR × this
TRAIL_ACTIVATE_RR      = 1.0    # activate after price moves 1:1 in profit
BREAKEVEN_ENABLE       = True   # move SL to breakeven at 1:1
BREAKEVEN_BUFFER_PIPS  = 5      # a few pips above entry for BE SL
PARTIAL_CLOSE_ENABLE   = True   # close 50% at 1:1 RR, let rest run
PARTIAL_CLOSE_RR       = 1.0    # at this RR, close partial
PARTIAL_CLOSE_PCT      = 0.5    # close this fraction (50%)

# ── Profit Protection ─────────────────────────────────────────
PROFIT_PROTECT_ENABLE  = True
PROFIT_LOCK_RR         = 1.5    # when floating profit hits 1.5× risk, lock 80%
PROFIT_LOCK_PCT        = 0.8    # lock this fraction of floating profit
DRAWDOWN_KILL_PCT      = 5.0    # if account drops 5% from equity peak → stop trading

# ── Re-entry Settings ─────────────────────────────────────────
REENTRY_ENABLE         = True
REENTRY_MIN_BARS       = 3      # wait at least 3 bars after close
REENTRY_CONDITION      = 0.65   # confidence threshold for re-entry
REENTRY_LOT_SCALE      = 0.75   # re-entry uses 75% of original lot

# ── Learning ──────────────────────────────────────────────────
LEARNING_ENABLE        = True
LEARNING_RATE          = 0.06
MIN_TRADES_TO_LEARN    = 3
MEMORY_FILE            = "gold_memory.json"
WEIGHTS_FILE           = "gold_weights.json"
SEQUENCES_FILE         = "gold_sequences.json"
STRATEGIES_FILE        = "gold_strategies.json"
OBSERVATIONS_FILE      = "gold_observations.json"
NEWS_CACHE_FILE        = "gold_news_cache.json"

# ── Strategy Weights (AI self-tunes these) ────────────────────
STRATEGY_WEIGHTS = {
    "ma_alignment":     22,   # MA stack alignment (key for gold)
    "ma_crossover":     15,   # MA cross signals (9/15, 9/21, 50/200)
    "ma_bounce":        18,   # Price bouncing off MA levels
    "rsi":              14,
    "macd":             13,
    "bollinger":        10,
    "stochastic":       10,
    "atr_momentum":     10,
    "session_bias":     12,
    "candlestick":      12,
    "chart_pattern":    12,
    "support_resist":   12,
    "gold_sentiment":   10,   # news/fundamental sentiment for gold
    "market_trap":      15,   # false breakout / trap detection
    "structure":        12,
}

# ── News API Keys (all free) ───────────────────────────────────
# Get free keys — takes 2 minutes to register:
ALPHA_VANTAGE_KEY = ""   # https://www.alphavantage.co/support/#api-key
NEWSAPI_KEY       = ""   # https://newsapi.org/register
FINNHUB_KEY       = ""   # https://finnhub.io/register
# RSS feeds always work without any key

# ── 24/7 Operation ────────────────────────────────────────────
SCAN_INTERVAL          = 15    # seconds between full analysis scans
TRAIL_INTERVAL         = 5     # seconds between trailing stop checks
WATCHDOG_INTERVAL      = 30
LOG_FILE               = "gold_ai.log"
TRADES_LOG             = "gold_trades.json"
MAX_LOG_LINES          = 25000

# ── Order Settings ────────────────────────────────────────────
MAGIC_NUMBER  = 20250429
COMMENT       = "DarkStare-Gold"
DEVIATION     = 25
AUTO_TRADE    = True
