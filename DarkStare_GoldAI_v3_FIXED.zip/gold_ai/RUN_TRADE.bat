@echo off
title Gold AI - AUTO TRADE
color 0C
cd /d "%~dp0"
echo Gold AI starting in AUTO-TRADE mode...
echo Press Ctrl+C to stop.
echo.
:loop
python bridge.py
echo Restarting...
timeout /t 5 /nobreak >nul 2>&1
goto loop
