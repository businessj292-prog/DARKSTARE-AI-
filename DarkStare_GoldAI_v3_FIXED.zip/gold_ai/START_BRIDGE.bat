@echo off
title DarkStare Gold AI v3
color 0E
cd /d "%~dp0"

echo.
echo  =====================================================
echo   DARKSTARE GOLD AI v3  -  XAUUSD MASTER  -  24/7
echo   Self-Learning / EAT Sessions / Profit Protection
echo  =====================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Python not found!
    echo  Install Python 3.10+ from python.org
    pause
    exit /b 1
)

echo  [1/3] Installing dependencies...
python -m pip install MetaTrader5 pandas numpy --quiet --upgrade
echo        Done.
echo.
echo  [2/3] Make sure MetaTrader 5 is OPEN and LOGGED IN.
echo.
echo  [3/3] Choose mode:
echo.
echo   [1]  AUTO-TRADE 24/7     (AI trades gold automatically)
echo   [2]  Analysis Only       (signals only, no orders)
echo   [3]  View AI Stats       (what the AI has learned)
echo   [4]  Install Boot Task   (auto-start on Windows login)
echo.
set /p choice=  Choice [1-4]: 

echo.

if "%choice%"=="1" goto mode_trade
if "%choice%"=="2" goto mode_analysis
if "%choice%"=="3" goto mode_stats
if "%choice%"=="4" goto mode_install
echo  Starting Analysis Only by default...
goto mode_analysis

:mode_trade
echo  Starting AUTO-TRADE 24/7...
echo  Press Ctrl+C to stop.
echo.
:loop_trade
python bridge.py
echo  Bridge stopped. Restarting in 10s... (Ctrl+C to cancel)
timeout /t 10 /nobreak >nul 2>&1
goto loop_trade

:mode_analysis
echo  Starting Analysis Only...
echo  Press Ctrl+C to stop.
echo.
:loop_analysis
python bridge.py --analysis-only
echo  Restarting in 10s...
timeout /t 10 /nobreak >nul 2>&1
goto loop_analysis

:mode_stats
echo.
echo  === GOLD AI LEARNING STATS ===
echo.
python -c "
try:
    import gold_brain as b
    print('MEMORY:', b.mem_stats())
    print()
    print('SEQUENCES:', b.seq_stats())
    print()
    print('STRATEGIES:', b.strat_stats())
    strats = b.list_strategies()
    if strats:
        for s in strats[:8]:
            wr = s.get('wr', 0)
            print('  [' + str(round(wr*100)) + 'pct] ' + s['name'])
    else:
        print('No strategies yet - keep trading to teach the AI')
    print()
    print('LEARNED WEIGHTS (top 5):')
    w = b.load_wgt()
    for k,v in sorted(w.items(), key=lambda x:x[1], reverse=True)[:5]:
        print(' ', k, ':', round(v,2))
except Exception as e:
    print('No data yet. Run the bridge first.')
    print('Detail:', e)
"
echo.
pause
goto :eof

:mode_install
echo  Installing auto-start task...
schtasks /create /tn "DarkStareGoldAI" /tr "\"%~f0\"" /sc ONLOGON /rl HIGHEST /f >nul 2>&1
if %errorlevel% equ 0 (
    echo  SUCCESS - Gold AI will auto-start at Windows login.
    echo  To remove: Task Scheduler - delete DarkStareGoldAI
) else (
    echo  FAILED - Right-click this .bat file and Run as Administrator.
)
echo.
pause
