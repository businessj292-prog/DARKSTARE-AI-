@echo off
title Install Dependencies
cd /d "%~dp0"
echo Installing Gold AI dependencies...
python -m pip install MetaTrader5 pandas numpy --upgrade
echo.
echo Done! You can now run START_BRIDGE.bat or RUN_TRADE.bat
pause
