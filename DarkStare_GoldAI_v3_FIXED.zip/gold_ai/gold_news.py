"""
gold_news.py — Gold-specific news & sentiment engine.
Free sources: RSS (always works), Alpha Vantage, Finnhub, NewsAPI.
Converts news into gold trading signals.
"""

import json, time, logging, re
from datetime import datetime
from pathlib import Path
import urllib.request, urllib.parse
import config

log = logging.getLogger("GoldAI")

NEWS_CACHE  = Path(config.NEWS_CACHE_FILE)
TTL         = 300   # cache 5 minutes

GOLD_BULL_KEYWORDS = [
    "safe haven","rate cut","fed cut","dovish","inflation rises","inflation surge",
    "dollar weakens","usd falls","gold rally","gold surges","geopolitical tension",
    "war","conflict","recession fears","bank crisis","economic uncertainty",
    "gold bullish","buy gold","gold demand","central bank gold","gold reserves",
    "weak jobs","nfp miss","unemployment rises","quantitative easing",
    "gold hits record","gold all time high","stagflation",
]
GOLD_BEAR_KEYWORDS = [
    "rate hike","fed hikes","hawkish","dollar strengthens","usd rises","risk on",
    "gold falls","gold drops","gold bearish","gold sell-off","strong jobs",
    "nfp beat","strong nfp","interest rate rise","gold pressure","gold down",
    "dollar index rises","dxy rally","real yields rise","inflation cools",
    "economy strong","gdp beats",
]
RISK_OFF = ["war","attack","crisis","crash","default","recession","pandemic","fear","collapse"]
RISK_ON  = ["rally","recovery","optimism","growth","deal","ceasefire","stimulus","boom"]

GOLD_RSS_FEEDS = [
    "https://www.kitco.com/rss/",
    "https://www.investing.com/rss/news_301.rss",
    "https://www.fxstreet.com/rss/news",
    "https://feeds.reuters.com/reuters/businessNews",
]

ECONOMIC_EVENTS = {
    "NFP":         ("Non-Farm Payrolls",   "HIGH",  "BEAR_USD_BULL_GOLD"),
    "CPI":         ("Consumer Price Index","HIGH",  "AMBIGUOUS"),
    "FOMC":        ("Fed Interest Decision","HIGH", "AMBIGUOUS"),
    "PMI":         ("PMI Manufacturing",   "MEDIUM","MILD"),
    "GDP":         ("GDP Release",         "HIGH",  "AMBIGUOUS"),
    "JOLTS":       ("Job Openings",        "MEDIUM","MILD"),
    "PPI":         ("Producer Price Index","MEDIUM","AMBIGUOUS"),
    "PCE":         ("PCE Price Index",     "HIGH",  "AMBIGUOUS"),
    "UNEMPLOYMENT":("Unemployment Rate",   "HIGH",  "BEAR_USD_BULL_GOLD"),
    "POWELL":      ("Fed Chair Speech",    "HIGH",  "AMBIGUOUS"),
    "RETAIL":      ("Retail Sales",        "MEDIUM","MILD"),
    "HOUSING":     ("Housing Data",        "LOW",   "MILD"),
}


def _fetch_rss(url: str, max_items: int = 8) -> list[dict]:
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": "Mozilla/5.0 GoldAI/1.0"})
        with urllib.request.urlopen(req, timeout=8) as r:
            content = r.read().decode("utf-8", "ignore")
        titles = re.findall(r"<title><!\[CDATA\[(.*?)\]\]></title>", content)
        descs  = re.findall(r"<description><!\[CDATA\[(.*?)\]\]></description>", content)
        if not titles:
            titles = re.findall(r"<title>(.*?)</title>", content)[1:]
        if not descs:
            descs  = re.findall(r"<description>(.*?)</description>", content)
        items = []
        for i, t in enumerate(titles[:max_items]):
            d = descs[i] if i < len(descs) else ""
            items.append({"title": t[:150], "summary": d[:200],
                           "source": url.split("/")[2]})
        return items
    except Exception as e:
        log.debug(f"RSS error {url}: {e}")
        return []


def _fetch_alpha_vantage() -> list[dict]:
    key = config.ALPHA_VANTAGE_KEY
    if not key: return []
    try:
        url = (f"https://www.alphavantage.co/query?function=NEWS_SENTIMENT"
               f"&tickers=FOREX:XAU&topics=gold,commodities"
               f"&apikey={key}&limit=10")
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read())
        items = []
        for feed in data.get("feed", [])[:6]:
            score = float(feed.get("overall_sentiment_score", 0))
            items.append({"title":   feed.get("title","")[:150],
                          "summary": feed.get("summary","")[:200],
                          "score":   score,
                          "source":  "AlphaVantage"})
        return items
    except Exception as e:
        log.debug(f"AlphaVantage error: {e}")
        return []


def _fetch_finnhub() -> list[dict]:
    key = config.FINNHUB_KEY
    if not key: return []
    try:
        url = f"https://finnhub.io/api/v1/news?category=forex&token={key}"
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read())
        return [{"title": a.get("headline","")[:150],
                 "summary": a.get("summary","")[:200],
                 "score": 0,
                 "source": "Finnhub"} for a in data[:6]]
    except Exception as e:
        log.debug(f"Finnhub error: {e}")
        return []


def _score_article(title: str, summary: str) -> float:
    text = (title + " " + summary).lower()
    score = 0.0
    for kw in GOLD_BULL_KEYWORDS:
        if kw in text: score += 0.35
    for kw in GOLD_BEAR_KEYWORDS:
        if kw in text: score -= 0.35
    for kw in RISK_OFF:
        if kw in text: score += 0.20
    for kw in RISK_ON:
        if kw in text: score -= 0.15
    # Special heavy hitters
    if "all time high" in text or "record high" in text: score += 0.6
    if "rate cut" in text and "fed" in text:              score += 0.5
    if "rate hike" in text and "fed" in text:             score -= 0.5
    return max(-1.0, min(1.0, score))


def _detect_economic_events(texts: list[str]) -> list[str]:
    events = []
    combined = " ".join(texts).upper()
    for key, (name, impact, gold_impact) in ECONOMIC_EVENTS.items():
        if key in combined:
            events.append(f"{name} [{impact} impact → {gold_impact}]")
    return events


def get_gold_news() -> dict:
    """Fetch and score all gold news. Returns trading signal dict."""
    cache = {}
    if NEWS_CACHE.exists():
        try:
            cache = json.loads(NEWS_CACHE.read_text(encoding="utf-8"))
            age = time.time() - cache.get("fetched_at", 0)
            if age < TTL:
                return cache
        except Exception:
            pass

    articles = []
    # Always try RSS (free, no key)
    for feed_url in GOLD_RSS_FEEDS[:2]:
        articles += _fetch_rss(feed_url)

    # API sources if keys configured
    articles += _fetch_alpha_vantage()
    articles += _fetch_finnhub()

    if not articles:
        return {"bias":"NEUTRAL","score":0.0,"headlines":[],
                "events":[],"note":"No news (RSS unavailable)",
                "fetched_at": time.time()}

    all_scores = []
    headlines  = []
    texts      = []
    for a in articles:
        t = a.get("title",""); s = a.get("summary","")
        sc = a.get("score", _score_article(t, s))
        all_scores.append(sc)
        if t: headlines.append(t)
        texts.append(t + " " + s)

    avg_score = sum(all_scores) / max(len(all_scores), 1)

    # Bias for gold
    if avg_score > 0.15:  bias = "BULLISH"
    elif avg_score < -0.15: bias = "BEARISH"
    else:                  bias = "NEUTRAL"

    events = _detect_economic_events(texts)
    top_hl = headlines[:4]

    result = {
        "bias":       bias,
        "score":      round(avg_score, 3),
        "headlines":  top_hl,
        "events":     events,
        "article_count": len(articles),
        "note":       (f"📰 {len(articles)} articles | Gold bias: {bias} "
                       f"(score {avg_score:+.2f})"),
        "fetched_at": time.time(),
    }

    NEWS_CACHE.write_text(json.dumps(result, indent=2, ensure_ascii=False),
                          encoding="utf-8")
    return result


def get_news_weight() -> tuple[float, float, str]:
    """Returns (bull_boost, bear_boost, note) for AI engine."""
    weight = 10.0
    try:
        news = get_gold_news()
        bias  = news.get("bias", "NEUTRAL")
        score = abs(news.get("score", 0))
        note  = news.get("note", "")
        if news.get("headlines"):
            note += f"\n    → {news['headlines'][0][:70]}"
        if news.get("events"):
            note += f"\n    ⚡ EVENT: {news['events'][0]}"
        strength = min(1.0, score * 2.5)
        if bias == "BULLISH": return weight*strength, 0.0, note
        if bias == "BEARISH": return 0.0, weight*strength, note
    except Exception as e:
        log.debug(f"News weight error: {e}")
    return 0.0, 0.0, "📰 News: NEUTRAL"
