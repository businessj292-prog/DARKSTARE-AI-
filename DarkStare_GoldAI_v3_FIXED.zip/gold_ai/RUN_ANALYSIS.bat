@echo off
title Gold AI - Analysis Mode
color 0A
cd /d "%~dp0"
echo Gold AI starting in Analysis mode...
echo Press Ctrl+C to stop.
echo.
:loop
python bridge.py --analysis-only
echo Restarting...
timeout /t 5 /nobreak >nul 2>&1
goto loop
