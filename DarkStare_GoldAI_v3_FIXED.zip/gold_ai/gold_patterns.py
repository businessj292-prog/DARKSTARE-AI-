"""
gold_patterns.py — Pattern Recognition Engine tuned for XAUUSD

Detects candlestick patterns, chart patterns, SMC concepts,
market traps (false breakouts, stop hunts, liquidity sweeps),
and MA interaction patterns.
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass
from gold_indicators import GoldIndicators


@dataclass
class Pattern:
    name:      str
    direction: str    # BULL / BEAR / NEUTRAL
    strength:  float  # 0–1
    note:      str
    category:  str = "candle"  # candle / chart / smc / trap / ma


def _body(o, c):   return abs(c - o)
def _range(h, l):  return h - l
def _bull(o, c):   return c > o
def _uw(o, c, hi): return hi - max(o, c)
def _lw(o, c, lo): return min(o, c) - lo


# ─── CANDLESTICK PATTERNS ─────────────────────────────────────

def detect_candles(df: pd.DataFrame) -> list[Pattern]:
    pats = []
    O = df["open"].values; H = df["high"].values
    L = df["low"].values;  C = df["close"].values
    n = len(df)
    if n < 4: return pats

    i = n-1  # last bar
    b = _body(O[i],C[i]); r = _range(H[i],L[i])
    uw = _uw(O[i],C[i],H[i]); lw = _lw(O[i],C[i],L[i])

    if r < 1e-9: return pats

    # ── Doji ─────────────────────────────────────────
    if b/r < 0.08:
        pats.append(Pattern("doji","NEUTRAL",0.4,"Doji — indecision","candle"))

    # ── Marubozu ─────────────────────────────────────
    if b/r > 0.88:
        d = "BULL" if _bull(O[i],C[i]) else "BEAR"
        pats.append(Pattern("marubozu",d,0.75,f"{d} Marubozu — strong momentum","candle"))

    # ── Hammer / Inverted Hammer ──────────────────────
    if lw/r > 0.60 and b/r < 0.30 and uw/r < 0.15:
        pats.append(Pattern("hammer","BULL",0.78,"Hammer — bullish reversal signal","candle"))
    if uw/r > 0.60 and b/r < 0.30 and lw/r < 0.15:
        pats.append(Pattern("shooting_star","BEAR",0.78,"Shooting Star — bearish reversal","candle"))

    # ── Pin Bar ──────────────────────────────────────
    if lw/r > 0.65 and b/r < 0.25:
        pats.append(Pattern("pin_bar_bull","BULL",0.82,"Bullish Pin Bar — strong rejection of lows","candle"))
    if uw/r > 0.65 and b/r < 0.25:
        pats.append(Pattern("pin_bar_bear","BEAR",0.82,"Bearish Pin Bar — strong rejection of highs","candle"))

    # ── Engulfing ────────────────────────────────────
    if n >= 2:
        i2 = n-2
        b2 = _body(O[i2],C[i2])
        if (not _bull(O[i2],C[i2]) and _bull(O[i],C[i]) and
                C[i]>O[i2] and O[i]<C[i2] and b>b2):
            pats.append(Pattern("bull_engulf","BULL",0.88,"Bullish Engulfing — powerful reversal","candle"))
        if (_bull(O[i2],C[i2]) and not _bull(O[i],C[i]) and
                C[i]<O[i2] and O[i]>C[i2] and b>b2):
            pats.append(Pattern("bear_engulf","BEAR",0.88,"Bearish Engulfing — powerful reversal","candle"))

    # ── Morning / Evening Star ────────────────────────
    if n >= 3:
        i3 = n-3; i2 = n-2
        mid_b = _body(O[i2],C[i2]); mid_r = _range(H[i2],L[i2])
        small_mid = mid_r > 0 and mid_b/mid_r < 0.28
        if (not _bull(O[i3],C[i3]) and small_mid and _bull(O[i],C[i]) and
                C[i] > (O[i3]+C[i3])/2):
            pats.append(Pattern("morning_star","BULL",0.92,"Morning Star — major bullish reversal","candle"))
        if (_bull(O[i3],C[i3]) and small_mid and not _bull(O[i],C[i]) and
                C[i] < (O[i3]+C[i3])/2):
            pats.append(Pattern("evening_star","BEAR",0.92,"Evening Star — major bearish reversal","candle"))

    # ── Tweezer Top/Bottom ────────────────────────────
    if n >= 2:
        i2 = n-2
        if abs(H[i]-H[i2]) < r*0.05 and _bull(O[i2],C[i2]) and not _bull(O[i],C[i]):
            pats.append(Pattern("tweezer_top","BEAR",0.72,"Tweezer Top — double rejection at highs","candle"))
        if abs(L[i]-L[i2]) < r*0.05 and not _bull(O[i2],C[i2]) and _bull(O[i],C[i]):
            pats.append(Pattern("tweezer_bot","BULL",0.72,"Tweezer Bottom — double rejection at lows","candle"))

    # ── Three White Soldiers / Three Black Crows ──────
    if n >= 3:
        last3_bull = all(_bull(O[n-3+k],C[n-3+k]) for k in range(3))
        last3_bear = all(not _bull(O[n-3+k],C[n-3+k]) for k in range(3))
        strong3    = all(_body(O[n-3+k],C[n-3+k])/_range(H[n-3+k],L[n-3+k])>0.6
                         for k in range(3) if _range(H[n-3+k],L[n-3+k])>0)
        if last3_bull and strong3:
            pats.append(Pattern("three_soldiers","BULL",0.85,"Three White Soldiers — strong momentum","candle"))
        if last3_bear and strong3:
            pats.append(Pattern("three_crows","BEAR",0.85,"Three Black Crows — strong sell pressure","candle"))

    return pats


# ─── CHART PATTERNS ───────────────────────────────────────────

def detect_chart(df: pd.DataFrame) -> list[Pattern]:
    pats = []
    H = df["high"].values; L = df["low"].values; C = df["close"].values
    n = len(df)
    if n < 40: return pats

    last20h = H[-20:]; last20l = L[-20:]
    atr = float(df["high"].subtract(df["low"]).rolling(14).mean().iloc[-1])

    # ── Double Top ───────────────────────────────────
    p1 = np.argmax(last20h[:10]); p2 = np.argmax(last20h[10:])+10
    if abs(last20h[p1]-last20h[p2])/max(last20h[p1],1) < 0.004:
        if C[-1] < min(last20h[p1],last20h[p2])-atr*0.2:
            pats.append(Pattern("double_top","BEAR",0.85,
                f"Double Top at {last20h[p1]:.1f} — strong resistance","chart"))

    # ── Double Bottom ─────────────────────────────────
    t1 = np.argmin(last20l[:10]); t2 = np.argmin(last20l[10:])+10
    if abs(last20l[t1]-last20l[t2])/max(last20l[t1],1) < 0.004:
        if C[-1] > max(last20l[t1],last20l[t2])+atr*0.2:
            pats.append(Pattern("double_bot","BULL",0.85,
                f"Double Bottom at {last20l[t1]:.1f} — strong support","chart"))

    # ── Bull/Bear Flag ────────────────────────────────
    if n >= 50:
        prev_move = C[-30] - C[-50]
        consol    = max(H[-15:]) - min(L[-15:])
        if prev_move > atr*3 and consol < abs(prev_move)*0.4:
            pats.append(Pattern("bull_flag","BULL",0.76,
                "Bull Flag — consolidation after strong up move","chart"))
        if prev_move < -atr*3 and consol < abs(prev_move)*0.4:
            pats.append(Pattern("bear_flag","BEAR",0.76,
                "Bear Flag — consolidation after strong down move","chart"))

    # ── Head & Shoulders ─────────────────────────────
    if n >= 60:
        seg = H[-60:]
        ls = np.argmax(seg[:20]); head = np.argmax(seg[20:40])+20; rs = np.argmax(seg[40:])+40
        if (seg[head]>seg[ls] and seg[head]>seg[rs] and
                abs(seg[ls]-seg[rs])/max(seg[head],1) < 0.02 and
                C[-1] < min(L[-20:])):
            pats.append(Pattern("head_shoulders","BEAR",0.88,
                "Head & Shoulders — major reversal pattern","chart"))

    return pats


# ─── MARKET TRAPS (false breakouts, stop hunts) ───────────────

def detect_traps(df: pd.DataFrame, ind: GoldIndicators) -> list[Pattern]:
    """
    Gold is notorious for stop hunts and false breakouts.
    Detect: Liquidity sweeps above highs/below lows,
    False breakouts above resistance / below support,
    Wick-through-level reversals.
    """
    pats = []
    H = df["high"].values; L = df["low"].values; C = df["close"].values
    O = df["open"].values
    n = len(df)
    if n < 20: return pats

    atr = ind.atr
    i   = n-1
    tol = atr * 0.15

    # ── Liquidity Sweep Above High → Bearish Trap ────
    recent_high = max(H[-20:-1])
    if (H[i] > recent_high and                      # wick above old high
        C[i] < recent_high - tol and                # closes back below
        _uw(O[i],C[i],H[i]) > _body(O[i],C[i])*2): # long upper wick
        pats.append(Pattern("liq_sweep_high","BEAR",0.88,
            f"Liquidity Sweep above {recent_high:.1f} — bull trap / stop hunt!","trap"))

    # ── Liquidity Sweep Below Low → Bullish Trap ─────
    recent_low = min(L[-20:-1])
    if (L[i] < recent_low and
        C[i] > recent_low + tol and
        _lw(O[i],C[i],L[i]) > _body(O[i],C[i])*2):
        pats.append(Pattern("liq_sweep_low","BULL",0.88,
            f"Liquidity Sweep below {recent_low:.1f} — bear trap / stop hunt!","trap"))

    # ── False Breakout above R1 ───────────────────────
    r1 = ind.r1
    if (H[i] > r1 and C[i] < r1 and H[i]-C[i] > atr*0.4):
        pats.append(Pattern("false_break_r1","BEAR",0.80,
            f"False Breakout above R1={r1:.1f} — bearish reversal","trap"))

    # ── False Breakout below S1 ───────────────────────
    s1 = ind.s1
    if (L[i] < s1 and C[i] > s1 and C[i]-L[i] > atr*0.4):
        pats.append(Pattern("false_break_s1","BULL",0.80,
            f"False Breakout below S1={s1:.1f} — bullish reversal","trap"))

    # ── Key Level Wick Rejection ──────────────────────
    key = ind.near_key_level
    if key > 0:
        if abs(H[i]-key) < tol and C[i] < key - tol:
            pats.append(Pattern("key_wick_bear","BEAR",0.75,
                f"Wick rejection at key level {key:.0f}","trap"))
        if abs(L[i]-key) < tol and C[i] > key + tol:
            pats.append(Pattern("key_wick_bull","BULL",0.75,
                f"Wick rejection at key support {key:.0f}","trap"))

    return pats


# ─── SMC / ICT ────────────────────────────────────────────────

def detect_smc(df: pd.DataFrame) -> list[Pattern]:
    pats = []
    H = df["high"].values; L = df["low"].values
    O = df["open"].values; C = df["close"].values
    n = len(df)
    if n < 10: return pats

    # Fair Value Gap
    for i in range(2, min(n,12)):
        idx = n-i
        if idx < 2: break
        if L[idx] > H[idx-2]:  # bullish FVG
            mid = (L[idx]+H[idx-2])/2
            pats.append(Pattern("fvg_bull","BULL",0.70,
                f"Bullish FVG at {mid:.1f} — unmitigated gap","smc")); break
        if H[idx] < L[idx-2]:  # bearish FVG
            mid = (H[idx]+L[idx-2])/2
            pats.append(Pattern("fvg_bear","BEAR",0.70,
                f"Bearish FVG at {mid:.1f} — unmitigated gap","smc")); break

    # Order Block
    for i in range(n-12, n-1):
        if i < 0: continue
        if C[i] < O[i]:  # bearish candle
            up_after = all(C[j]>O[j] for j in range(i+1, min(i+4,n)))
            if up_after:
                pats.append(Pattern("ob_bull","BULL",0.80,
                    f"Bullish Order Block at {C[i]:.1f}","smc")); break
        if C[i] > O[i]:
            dn_after = all(C[j]<O[j] for j in range(i+1, min(i+4,n)))
            if dn_after:
                pats.append(Pattern("ob_bear","BEAR",0.80,
                    f"Bearish Order Block at {C[i]:.1f}","smc")); break

    return pats


# ─── MA INTERACTION PATTERNS ──────────────────────────────────

def detect_ma_patterns(df: pd.DataFrame, ind: GoldIndicators) -> list[Pattern]:
    pats = []
    p = ind.close

    # ── MA Crossovers ────────────────────────────────
    if ind.cross_9_15_bull:
        pats.append(Pattern("cross_9_15_bull","BULL",0.72,
            "EMA9 crossed above EMA15 — short-term bull signal","ma"))
    if ind.cross_9_15_bear:
        pats.append(Pattern("cross_9_15_bear","BEAR",0.72,
            "EMA9 crossed below EMA15 — short-term bear signal","ma"))
    if ind.cross_9_21_bull:
        pats.append(Pattern("cross_9_21_bull","BULL",0.78,
            "EMA9 crossed above EMA21 — momentum turning bullish","ma"))
    if ind.cross_9_21_bear:
        pats.append(Pattern("cross_9_21_bear","BEAR",0.78,
            "EMA9 crossed below EMA21 — momentum turning bearish","ma"))
    if ind.cross_50_200_bull:
        pats.append(Pattern("golden_cross","BULL",0.95,
            "🌟 GOLDEN CROSS: EMA50 crossed above EMA200 — major bull signal!","ma"))
    if ind.cross_50_200_bear:
        pats.append(Pattern("death_cross","BEAR",0.95,
            "💀 DEATH CROSS: EMA50 crossed below EMA200 — major bear signal!","ma"))

    # ── Bounce off MA ────────────────────────────────
    bounce_map = {
        "bounce_ema9":  ("EMA9",  0.62, ind.ema9),
        "bounce_ema21": ("EMA21", 0.72, ind.ema21),
        "bounce_ema50": ("EMA50", 0.78, ind.ema50),
        "bounce_ema80": ("EMA80", 0.80, ind.ema80),
        "bounce_sma80": ("SMA80", 0.80, ind.sma80),
        "bounce_ema200":("EMA200",0.88, ind.ema200),
        "bounce_sma200":("SMA200",0.88, ind.sma200),
    }
    for attr, (label, strength, level) in bounce_map.items():
        if getattr(ind, attr, False):
            d = ind.bounce_direction
            if d != "NONE":
                pats.append(Pattern(f"bounce_{attr}",d,strength,
                    f"Price bouncing off {label}={level:.1f} — {d.lower()} continuation","ma"))

    # ── MA Compression → Breakout ─────────────────────
    if ind.mas_converging:
        pats.append(Pattern("ma_compress","NEUTRAL",0.65,
            "MAs compressing — explosive breakout imminent","ma"))

    # ── Pullback to MA in trend ───────────────────────
    if ind.ma_stack_bull and ind.bounce_ema21:
        pats.append(Pattern("pullback_bull","BULL",0.85,
            "Pullback to EMA21 in bullish MA stack — buy the dip","ma"))
    if ind.ma_stack_bear and ind.bounce_ema21:
        pats.append(Pattern("pullback_bear","BEAR",0.85,
            "Pullback to EMA21 in bearish MA stack — sell the rally","ma"))

    return pats


# ─── FULL DETECTOR ────────────────────────────────────────────

def detect_all(df: pd.DataFrame, ind: GoldIndicators) -> dict:
    all_pats = (detect_candles(df) + detect_chart(df) +
                detect_traps(df, ind) + detect_smc(df) +
                detect_ma_patterns(df, ind) +
                detect_equal_highs_lows(df, ind))

    bull = sum(p.strength for p in all_pats if p.direction=="BULL")
    bear = sum(p.strength for p in all_pats if p.direction=="BEAR")
    best = max(all_pats, key=lambda p: p.strength, default=None)

    return {
        "all":        [{"n":p.name,"d":p.direction,"s":p.strength,
                        "note":p.note,"cat":p.category} for p in all_pats],
        "bull_score": round(bull,2),
        "bear_score": round(bear,2),
        "top":        best.name if best else "none",
        "top_dir":    best.direction if best else "NEUTRAL",
        "top_str":    best.strength if best else 0,
        "top_note":   best.note if best else "",
        "notes":      [p.note for p in sorted(all_pats,
                        key=lambda x:x.strength,reverse=True)[:6]],
        "trap_detected": any(p.category=="trap" for p in all_pats),
    }


# ─── EQUAL HIGHS / EQUAL LOWS ────────────────────────────────

def detect_equal_highs_lows(df: pd.DataFrame, ind) -> list[Pattern]:
    """
    Equal Highs (EQH) and Equal Lows (EQL) — one of the most
    powerful SMC/ICT concepts for gold.

    What they mean:
      EQH = two or more swing highs at nearly the SAME price level.
            Market makers KNOW stop losses cluster just above these.
            Price often sweeps EQH (hunts stops), then REVERSES BEARISH.
            Rule: Wait for the sweep → wick above EQH → close below → SELL.

      EQL = two or more swing lows at nearly the SAME price level.
            Stop losses cluster below. Price sweeps EQL, then REVERSES BULLISH.
            Rule: Wait for the sweep → wick below EQL → close above → BUY.

    Confirmations required (tracked here):
      1. At least 2 touches of the level (more = stronger)
      2. Price approaches from the right direction
      3. A wick/shadow through the level (the sweep)
      4. Close back INSIDE the level (rejection confirmed)
      5. Volume spike on the sweep bar (optional but strong)
    """
    pats = []
    H = df["high"].values
    L = df["low"].values
    C = df["close"].values
    O = df["open"].values
    n = len(df)
    if n < 20:
        return pats

    atr = ind.atr
    # Tolerance: two levels are "equal" if within 15% of ATR
    tol = atr * 0.15

    # ── Find swing highs ─────────────────────────────
    wing = 4  # bars each side
    swing_highs = []
    for i in range(wing, n - wing):
        if H[i] == max(H[i - wing: i + wing + 1]):
            swing_highs.append((i, H[i]))

    # ── Find swing lows ──────────────────────────────
    swing_lows = []
    for i in range(wing, n - wing):
        if L[i] == min(L[i - wing: i + wing + 1]):
            swing_lows.append((i, L[i]))

    i_last = n - 1  # current bar

    # ══ EQUAL HIGHS DETECTION ════════════════════════
    if len(swing_highs) >= 2:
        # Group highs that are at the same level
        for j in range(len(swing_highs) - 1, 0, -1):
            h1_idx, h1_val = swing_highs[j]
            cluster = [(h1_idx, h1_val)]
            for k in range(j - 1, max(j - 6, -1), -1):
                h2_idx, h2_val = swing_highs[k]
                if abs(h1_val - h2_val) <= tol:
                    cluster.append((h2_idx, h2_val))

            if len(cluster) >= 2:
                eq_level = sum(v for _, v in cluster) / len(cluster)
                touches  = len(cluster)
                # Check if current price is approaching from below
                approaching_from_below = C[i_last] < eq_level and C[i_last] > eq_level - atr * 2

                # Check for sweep: wick above EQH, close back below
                swept = H[i_last] > eq_level and C[i_last] < eq_level
                # Pre-sweep: price just touching
                at_level = abs(H[i_last] - eq_level) < tol

                strength = min(0.98, 0.65 + touches * 0.1)

                if swept:
                    # CONFIRMED sweep of equal highs → strong sell
                    pats.append(Pattern(
                        "eqh_sweep_confirmed", "BEAR", strength + 0.05,
                        f"⚡ EQH SWEPT at {eq_level:.2f} ({touches} touches) — "
                        f"Stop hunt complete! SELL reversal confirmed. "
                        f"Stops triggered above {eq_level:.2f}, smart money selling.",
                        "smc"
                    ))
                elif at_level:
                    pats.append(Pattern(
                        "eqh_test", "BEAR", strength - 0.1,
                        f"⚠ Price testing EQH at {eq_level:.2f} ({touches} touches) — "
                        f"Watch for sweep and rejection. "
                        f"Liquidity pool above. Prepare SELL on wick+close below.",
                        "smc"
                    ))
                elif approaching_from_below:
                    pats.append(Pattern(
                        "eqh_approach", "NEUTRAL", 0.55,
                        f"Price approaching EQH zone {eq_level:.2f} ({touches} touches) — "
                        f"Caution: stop hunt risk. Wait for reaction.",
                        "smc"
                    ))
                break  # use most recent equal high cluster

    # ══ EQUAL LOWS DETECTION ═════════════════════════
    if len(swing_lows) >= 2:
        for j in range(len(swing_lows) - 1, 0, -1):
            l1_idx, l1_val = swing_lows[j]
            cluster = [(l1_idx, l1_val)]
            for k in range(j - 1, max(j - 6, -1), -1):
                l2_idx, l2_val = swing_lows[k]
                if abs(l1_val - l2_val) <= tol:
                    cluster.append((l2_idx, l2_val))

            if len(cluster) >= 2:
                eq_level = sum(v for _, v in cluster) / len(cluster)
                touches  = len(cluster)
                approaching_from_above = C[i_last] > eq_level and C[i_last] < eq_level + atr * 2

                swept = L[i_last] < eq_level and C[i_last] > eq_level
                at_level = abs(L[i_last] - eq_level) < tol

                strength = min(0.98, 0.65 + touches * 0.1)

                if swept:
                    pats.append(Pattern(
                        "eql_sweep_confirmed", "BULL", strength + 0.05,
                        f"⚡ EQL SWEPT at {eq_level:.2f} ({touches} touches) — "
                        f"Bear trap / stop hunt complete! BUY reversal confirmed. "
                        f"Stops cleared below {eq_level:.2f}, smart money buying.",
                        "smc"
                    ))
                elif at_level:
                    pats.append(Pattern(
                        "eql_test", "BULL", strength - 0.1,
                        f"⚠ Price testing EQL at {eq_level:.2f} ({touches} touches) — "
                        f"Watch for sweep and rejection. "
                        f"Liquidity pool below. Prepare BUY on wick+close above.",
                        "smc"
                    ))
                elif approaching_from_above:
                    pats.append(Pattern(
                        "eql_approach", "NEUTRAL", 0.55,
                        f"Price approaching EQL zone {eq_level:.2f} ({touches} touches) — "
                        f"Bear trap risk. Wait for sweep reaction before entry.",
                        "smc"
                    ))
                break

    # ══ TRIPLE TOUCH = PREMIUM LEVEL ════════════════
    # If same level touched 3+ times: even stronger signal
    for p in pats:
        if "touches)" in p.note:
            try:
                t = int(p.note.split("(")[1].split(" touch")[0])
                if t >= 3:
                    p.strength = min(0.99, p.strength + 0.08)
                    p.note = "🔴 PREMIUM " + p.note if "SELL" in p.note or "BEAR" in p.note else "🟢 PREMIUM " + p.note
            except Exception:
                pass

    return pats
