"""
gold_brain.py — Gold AI Memory, Pattern Sequence Learning & Strategy Discovery

Three systems in one:
  1. MEMORY        — trade history, win/loss, per-condition stats
  2. SEQ LEARNER   — tokenizes market state, tracks what sequences WIN
  3. STRAT CREATOR — discovers + names new strategies from repeated patterns
"""

import json, hashlib, random
from datetime import datetime
from pathlib import Path
from collections import defaultdict
import config

# ─── FILE PATHS ───────────────────────────────────────────────
MEM_FILE  = Path(config.MEMORY_FILE)
WGT_FILE  = Path(config.WEIGHTS_FILE)
SEQ_FILE  = Path(config.SEQUENCES_FILE)
STR_FILE  = Path(config.STRATEGIES_FILE)
OBS_FILE  = Path(config.OBSERVATIONS_FILE)


# ══════════════════════════════════════════════════════════════
#  1. MEMORY
# ══════════════════════════════════════════════════════════════

def _def_mem():
    return {"version":"3.0","total_trades":0,"wins":0,"losses":0,
            "total_pnl":0.0,"best":0.0,"worst":0.0,"trades":[],
            "key_levels":[],"pattern_stats":{},"strategy_stats":{},
            "session_stats":{},"atr_tune":{"sl_mult":config.ATR_SL_MULT,
            "tp_mult":config.ATR_TP_MULT},"last_updated":""}

def _load(path, default):
    if path.exists():
        try:
            d = json.loads(path.read_text(encoding="utf-8"))
            for k,v in default.items():
                if k not in d: d[k]=v
            return d
        except Exception: pass
    return dict(default)

def _save(path, data):
    data["last_updated"] = datetime.now().isoformat()
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def load_mem():  return _load(MEM_FILE, _def_mem())
def load_wgt():  return _load(WGT_FILE, dict(config.STRATEGY_WEIGHTS))
def save_mem(m): _save(MEM_FILE, m)
def save_wgt(w): WGT_FILE.write_text(json.dumps(w, indent=2), encoding="utf-8")


def record_open(ticket, direction, entry, sl, tp, lot, conf,
                strats, pattern, session):
    m = load_mem()
    m["trades"].append({"ticket":ticket,"direction":direction,"entry":entry,
        "sl":sl,"tp":tp,"lot":lot,"conf":conf,"strats":strats,
        "pattern":pattern,"session":session,
        "open_time":datetime.now().isoformat(),
        "close_time":None,"close_price":None,"pnl":None,"result":None})
    if len(m["trades"])>500: m["trades"]=m["trades"][-500:]
    save_mem(m)


def record_close(ticket, close_price, pnl, tokens=None):
    m = load_mem()
    for t in reversed(m["trades"]):
        if t["ticket"]==ticket and t["result"] is None:
            t.update({"close_time":datetime.now().isoformat(),
                      "close_price":close_price,"pnl":pnl,
                      "result":"WIN" if pnl>0 else ("BE" if pnl==0 else "LOSS")})
            m["total_trades"]+=1; m["total_pnl"]+=pnl
            if pnl>0: m["wins"]+=1;  m["best"] =max(m["best"], pnl)
            else:     m["losses"]+=1;m["worst"]=min(m["worst"],pnl)

            ses = t.get("session","?")
            ss  = m["session_stats"].setdefault(ses,{"wins":0,"losses":0})
            if pnl>0: ss["wins"]+=1
            else:     ss["losses"]+=1

            pat = t.get("pattern","none")
            ps  = m["pattern_stats"].setdefault(pat,{"wins":0,"losses":0,"pnl":0.0})
            ps["pnl"]+=pnl
            if pnl>0: ps["wins"]+=1
            else:     ps["losses"]+=1

            for s in t.get("strats",[]):
                sts=m["strategy_stats"].setdefault(s,{"wins":0,"losses":0})
                if pnl>0: sts["wins"]+=1
                else:     sts["losses"]+=1

            save_mem(m)
            # Trigger learning
            if config.LEARNING_ENABLE and m["total_trades"]>=config.MIN_TRADES_TO_LEARN:
                _learn(m)
            # Sequence learning
            if tokens:
                record_sequence(tokens, t.get("direction","BUY"), pnl>0, pnl)
            return t["result"]
    save_mem(m); return None


def _learn(m):
    w = load_wgt(); lr = config.LEARNING_RATE
    for strat, stats in m["strategy_stats"].items():
        if strat not in w: continue
        total = stats["wins"]+stats["losses"]
        if total<3: continue
        wr    = stats["wins"]/total
        delta = (wr-0.5)*2*lr*w[strat]
        w[strat] = round(max(1, min(60, w[strat]+delta)), 2)
    save_wgt(w)
    # Tune ATR multipliers
    total = m["wins"]+m["losses"]
    if total>=5:
        wr = m["wins"]/total
        t  = m["atr_tune"]
        if wr<0.4: t["sl_mult"]=round(min(3.0,t["sl_mult"]+0.05),2)
        elif wr>0.65:
            t["sl_mult"]=round(max(0.8,t["sl_mult"]-0.02),2)
            t["tp_mult"]=round(min(5.0,t["tp_mult"]+0.05),2)
    save_mem(m)


def remember_level(price, ltype):
    m=load_mem(); threshold=price*0.001
    for lv in m["key_levels"]:
        if abs(lv["price"]-price)<threshold:
            lv["seen"]+=1; save_mem(m); return
    m["key_levels"].append({"price":round(price,3),"type":ltype,
                              "seen":1,"time":datetime.now().isoformat()})
    m["key_levels"]=sorted(m["key_levels"],key=lambda x:x["seen"],reverse=True)[:80]
    save_mem(m)


def get_strong_levels(current, atr):
    m=load_mem(); window=atr*4
    nearby=[lv for lv in m["key_levels"]
            if abs(lv["price"]-current)<window and lv["seen"]>=2]
    sup=[lv["price"] for lv in nearby if lv["price"]<current]
    res=[lv["price"] for lv in nearby if lv["price"]>current]
    return {"support":sorted(sup,reverse=True)[:3],
            "resistance":sorted(res)[:3]}


def get_atr_tune():
    m=load_mem(); t=m.get("atr_tune",{})
    return (t.get("sl_mult",config.ATR_SL_MULT),
            t.get("tp_mult",config.ATR_TP_MULT))


def mem_stats():
    m=load_mem(); t=m["total_trades"]; w=m["wins"]
    wr=f"{w/t*100:.1f}%" if t>0 else "N/A"
    return (f"Trades:{t} W:{w} L:{m['losses']} WR:{wr} "
            f"PnL:{m['total_pnl']:.2f} Best:{m['best']:.2f} Worst:{m['worst']:.2f}")


# ══════════════════════════════════════════════════════════════
#  2. SEQUENCE PATTERN LEARNER
# ══════════════════════════════════════════════════════════════

MAX_SEQ = 3000

def tokenize(ind_dict: dict, session: str, top_pattern: str, structure: str) -> list[str]:
    toks=[]
    rsi=ind_dict.get("rsi",50)
    if rsi<=22:   toks.append("RSI_EXTREME_OS")
    elif rsi<=32: toks.append("RSI_OS")
    elif rsi<=45: toks.append("RSI_BELOW_MID")
    elif rsi>=78: toks.append("RSI_EXTREME_OB")
    elif rsi>=68: toks.append("RSI_OB")
    elif rsi>=55: toks.append("RSI_ABOVE_MID")
    else:         toks.append("RSI_NEUTRAL")

    # MA stack
    if ind_dict.get("ma_stack_bull"): toks.append("MA_STACK_BULL")
    elif ind_dict.get("ma_stack_bear"):toks.append("MA_STACK_BEAR")
    elif ind_dict.get("ma_trend")=="BULL": toks.append("MA_PART_BULL")
    elif ind_dict.get("ma_trend")=="BEAR": toks.append("MA_PART_BEAR")
    else: toks.append("MA_MIXED")

    toks.append("P_ABOVE_EMA200" if ind_dict.get("price_vs_ema200")=="ABOVE"
                else "P_BELOW_EMA200")

    # MACD
    m=ind_dict.get("macd",0); s=ind_dict.get("macd_sig",0); h=ind_dict.get("macd_hist",0)
    if m>s and h>0 and m>0: toks.append("MACD_BULL_STRONG")
    elif m>s and h>0:        toks.append("MACD_BULL")
    elif m<s and h<0 and m<0:toks.append("MACD_BEAR_STRONG")
    elif m<s and h<0:        toks.append("MACD_BEAR")
    else:                    toks.append("MACD_NEUTRAL")

    # BB
    p=ind_dict.get("close",0)
    bbu=ind_dict.get("bb_upper",p+1); bbl=ind_dict.get("bb_lower",p-1)
    bbm=ind_dict.get("bb_mid",p);     bbw=ind_dict.get("bb_width",0.02)
    if p<=bbl:         toks.append("BB_LOWER")
    elif p>=bbu:       toks.append("BB_UPPER")
    elif p>bbm:        toks.append("BB_ABOVE_MID")
    else:              toks.append("BB_BELOW_MID")
    if bbw<0.01:       toks.append("BB_SQUEEZE")

    # Stoch
    k=ind_dict.get("stoch_k",50); d=ind_dict.get("stoch_d",50)
    if k<20 and k>d:  toks.append("STOCH_OS_X")
    elif k<30:        toks.append("STOCH_OS")
    elif k>80 and k<d:toks.append("STOCH_OB_X")
    elif k>70:        toks.append("STOCH_OB")

    # Bounces (special gold tokens)
    if ind_dict.get("bounce_ema21"): toks.append("BOUNCE_EMA21")
    if ind_dict.get("bounce_ema50"): toks.append("BOUNCE_EMA50")
    if ind_dict.get("bounce_ema80"): toks.append("BOUNCE_EMA80")
    if ind_dict.get("bounce_sma80"): toks.append("BOUNCE_SMA80")
    if ind_dict.get("bounce_ema200"):toks.append("BOUNCE_EMA200")

    # MA crosses
    if ind_dict.get("cross_9_15_bull"):  toks.append("X_9_15_BULL")
    if ind_dict.get("cross_9_21_bull"):  toks.append("X_9_21_BULL")
    if ind_dict.get("cross_9_15_bear"):  toks.append("X_9_15_BEAR")
    if ind_dict.get("cross_9_21_bear"):  toks.append("X_9_21_BEAR")
    if ind_dict.get("cross_50_200_bull"):toks.append("GOLDEN_CROSS")
    if ind_dict.get("cross_50_200_bear"):toks.append("DEATH_CROSS")

    # Structure
    if ind_dict.get("hh") and ind_dict.get("hl"): toks.append("STRUCT_BULL")
    elif ind_dict.get("lh") and ind_dict.get("ll"):toks.append("STRUCT_BEAR")

    # Momentum
    m10=ind_dict.get("mom10",0)
    toks.append("MOM_BULL" if m10>0 else "MOM_BEAR")
    vr=ind_dict.get("vol_ratio",1.0)
    if vr>1.8: toks.append("VOL_SPIKE")
    elif vr>1.3:toks.append("VOL_HIGH")

    # Session
    toks.append(f"SES_{session.upper()}")
    # Pattern
    if top_pattern and top_pattern not in ("none",""):
        toks.append(f"PAT_{top_pattern.upper()}")
    # Structure
    if structure:
        toks.append(f"STR_{structure.upper()[:10]}")

    return toks


def _seq_encode(toks, direction, n=0):
    key = "|".join(sorted(toks[:n] if n else toks))+f"|{direction}"
    return key

def _load_seq(): return _load(SEQ_FILE,{"seqs":{},"total":0})
def _save_seq(d):
    s=d["seqs"]
    if len(s)>MAX_SEQ:
        top=sorted(s,key=lambda k:s[k]["total"],reverse=True)[:MAX_SEQ]
        d["seqs"]={k:s[k] for k in top}
    SEQ_FILE.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding="utf-8")


def record_sequence(toks, direction, won, pnl):
    d=_load_seq(); s=d["seqs"]
    for key in [_seq_encode(toks,direction),
                _seq_encode(toks,direction,5),
                _seq_encode(toks,direction,4)]:
        e=s.setdefault(key,{"wins":0,"losses":0,"total":0,"pnl":0.0,"ts":""})
        e["total"]+=1; e["pnl"]+=round(pnl,2); e["ts"]=datetime.now().isoformat()
        if won: e["wins"]+=1
        else:   e["losses"]+=1
    d["total"]+=1; _save_seq(d)


def get_seq_boost(toks, direction, min_occ=3):
    d=_load_seq(); s=d["seqs"]
    best_boost=1.0; best_note=""
    for key in [_seq_encode(toks,direction),
                _seq_encode(toks,direction,5),
                _seq_encode(toks,direction,4),
                _seq_encode(toks,direction,3)]:
        if key not in s: continue
        e=s[key]
        if e["total"]<min_occ: continue
        wr=e["wins"]/e["total"]
        boost=0.5+wr
        if e["total"]>s.get(key,{}).get("total",0) or boost>best_boost:
            best_boost=round(boost,3)
            best_note=(f"Seq learned: WR {wr*100:.0f}% "
                       f"({e['wins']}/{e['total']} trades)")
    return best_boost, best_note


def seq_stats():
    d=_load_seq(); s=d["seqs"]
    valid=[v for v in s.values() if v["total"]>=3]
    if not valid: return f"Sequences: {len(s)} recorded, learning..."
    avg=sum(v["wins"]/v["total"] for v in valid)/len(valid)
    return (f"Sequences:{len(s)} | Qualified:{len(valid)} | "
            f"AvgWR:{avg*100:.1f}% | Total:{d['total']}")


# ══════════════════════════════════════════════════════════════
#  3. STRATEGY DISCOVERY ENGINE
# ══════════════════════════════════════════════════════════════

MIN_OCC   = 6
MIN_WR    = 0.60
MIN_AVG_RR= 1.4

_SESS   = ["London","New York","Asian","Overlap","Killzone","Pre-Session"]
_ACTION = ["Surge","Rejection","Reversal","Trap","Sweep","Flush","Continuation",
           "Breakout","Pullback","Compression","Acceleration","Absorption"]
_SUFFIX = ["Protocol","Setup","Signal","Formation","Method","Algorithm","System"]
_GOLD   = ["Gold","Bullion","XAU","Metal","Commodity","Safe-Haven"]


def _name(toks, direction):
    h=int(hashlib.md5("|".join(sorted(toks[:5])).encode()).hexdigest()[:8],16)
    random.seed(h)
    s=_SESS[h%len(_SESS)]; g=_GOLD[(h>>4)%len(_GOLD)]
    a=_ACTION[(h>>8)%len(_ACTION)]; sf=_SUFFIX[(h>>12)%len(_SUFFIX)]
    d="Bull" if direction=="BUY" else "Bear"
    return f"{s} {g} {d} {a} {sf}"


def _load_str(): return _load(STR_FILE,{"strategies":{},"discovered":0,"deployed":0})
def _save_str(d): STR_FILE.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding="utf-8")
def _load_obs(): return _load(OBS_FILE,{"obs":[],"total":0})
def _save_obs(d):
    if len(d["obs"])>5000: d["obs"]=d["obs"][-4000:]
    OBS_FILE.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding="utf-8")


def record_obs(toks, direction, session, conf, rr, outcome=None, pnl=0.0):
    obs=_load_obs(); sig=hashlib.md5("|".join(sorted(toks)).encode()).hexdigest()[:12]
    if outcome is None:
        obs["obs"].append({"sig":sig,"toks":toks[:8],"dir":direction,
            "ses":session,"conf":conf,"rr":rr,"outcome":None,"pnl":0.0,
            "time":datetime.now().isoformat()})
        obs["total"]+=1
    else:
        for o in reversed(obs["obs"]):
            if o["sig"]==sig and o["outcome"] is None:
                o["outcome"]=outcome; o["pnl"]=pnl; break
    _save_obs(obs)
    if outcome:
        _discover(obs)


def _discover(obs_data):
    import logging as _log
    log=_log.getLogger("GoldAI")
    done=[o for o in obs_data["obs"] if o["outcome"]]
    if len(done)<MIN_OCC: return
    groups=defaultdict(list)
    for o in done:
        key="|".join(sorted(o["toks"][:4]))+"|"+o["dir"]
        groups[key].append(o)
    strats=_load_str()
    for key, outcomes in groups.items():
        if len(outcomes)<MIN_OCC: continue
        wins  =[o for o in outcomes if o["outcome"]=="WIN"]
        losses=[o for o in outcomes if o["outcome"]=="LOSS"]
        total =len(wins)+len(losses)
        if total<MIN_OCC: continue
        wr=len(wins)/total
        avg_rr=sum(o["rr"] for o in outcomes)/len(outcomes)
        avg_pnl=sum(o["pnl"] for o in outcomes)/len(outcomes)
        if wr<MIN_WR or avg_rr<MIN_AVG_RR: continue

        if key in strats["strategies"]:
            s=strats["strategies"][key]
            s.update({"wins":len(wins),"losses":len(losses),
                      "wr":round(wr,3),"avg_rr":round(avg_rr,2),
                      "avg_pnl":round(avg_pnl,2),
                      "last_seen":datetime.now().isoformat()})
            _save_str(strats); continue

        direction=key.split("|")[-1]; tok_list=key.split("|")[:-1]
        name=_name(tok_list, direction)
        rules=_tok_to_rules(tok_list, direction)
        strategy={"id":key[:16],"name":name,"direction":direction,
                  "toks":tok_list,"wins":len(wins),"losses":len(losses),
                  "wr":round(wr,3),"avg_rr":round(avg_rr,2),
                  "avg_pnl":round(avg_pnl,2),
                  "session":outcomes[-1]["ses"],
                  "discovered":datetime.now().isoformat(),
                  "last_seen":datetime.now().isoformat(),
                  "rules":rules,"deployments":0,"active":True}
        strats["strategies"][key]=strategy
        strats["discovered"]+=1; _save_str(strats)

        log.info("")
        log.info("★"*60)
        log.info(f"  🔬 NEW GOLD STRATEGY: «{name}»")
        log.info(f"  Direction:{direction} WR:{wr*100:.1f}% ({total} trades) AvgRR:{avg_rr:.2f}")
        for r in rules[:5]: log.info(f"    → {r}")
        log.info("★"*60)


_RULE_MAP={
    "RSI_OS":"RSI oversold (≤32)","RSI_EXTREME_OS":"RSI extreme oversold (≤22)",
    "RSI_OB":"RSI overbought (≥68)","RSI_EXTREME_OB":"RSI extreme overbought (≥78)",
    "MA_STACK_BULL":"All EMAs aligned bullish (9>21>50>200)","MA_STACK_BEAR":"All EMAs aligned bearish",
    "MACD_BULL_STRONG":"MACD bullish crossover above zero","MACD_BEAR_STRONG":"MACD bearish crossover below zero",
    "BB_LOWER":"Price at Bollinger Lower Band","BB_UPPER":"Price at Bollinger Upper Band",
    "BB_SQUEEZE":"Bollinger squeeze — breakout pending",
    "STOCH_OS_X":"Stochastic oversold K/D cross","STOCH_OB_X":"Stochastic overbought K/D cross",
    "BOUNCE_EMA21":"Price bouncing off EMA21","BOUNCE_EMA50":"Price bouncing off EMA50",
    "BOUNCE_EMA80":"Price bouncing off EMA80","BOUNCE_EMA200":"Price bouncing off EMA200",
    "BOUNCE_SMA80":"Price bouncing off SMA80",
    "X_9_15_BULL":"EMA9 crossed above EMA15","X_9_21_BULL":"EMA9 crossed above EMA21",
    "X_9_15_BEAR":"EMA9 crossed below EMA15","X_9_21_BEAR":"EMA9 crossed below EMA21",
    "GOLDEN_CROSS":"Golden Cross (EMA50 above EMA200)","DEATH_CROSS":"Death Cross",
    "STRUCT_BULL":"Market structure HH/HL confirmed","STRUCT_BEAR":"Market structure LH/LL confirmed",
    "VOL_SPIKE":"Volume spike (>1.8× average)","MOM_BULL":"Positive momentum",
}

def _tok_to_rules(toks, direction):
    rules=[_RULE_MAP.get(t, t.replace("_"," ").title()) for t in toks]
    rules+=[f"Direction: {direction}",
            "SL: ATR×learned_multiplier below/above entry",
            f"TP: Minimum RR {MIN_AVG_RR}:1"]
    return rules[:8]


def get_strategy_boost(toks, direction):
    strats=_load_str(); tok_set=set(toks)
    best_score=0.0; best_name=""
    for key,s in strats["strategies"].items():
        if not s.get("active",True) or s["direction"]!=direction: continue
        if s["wr"]<MIN_WR: continue
        overlap=len(set(s["toks"])&tok_set)/max(len(s["toks"]),1)
        if overlap>=0.55:
            score=s["wr"]*overlap*18
            if score>best_score:
                best_score=score; best_name=s["name"]
                s["deployments"]=s.get("deployments",0)+1
    if best_score>0: _save_str(strats)
    return round(best_score,2), best_name


def strat_stats():
    d=_load_str(); obs=_load_obs()
    return (f"Strategies:{d['discovered']} active | "
            f"Observations:{obs['total']}")


def list_strategies():
    d = _load_str()
    result = list(d["strategies"].values())
    result.sort(key=lambda x: x["wr"], reverse=True)
    return result
