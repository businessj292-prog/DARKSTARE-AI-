"""mt5_connector.py — MT5 interface for Gold AI."""
import MetaTrader5 as mt5
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging, config
log = logging.getLogger("GoldAI")

TF_MAP={"M1":mt5.TIMEFRAME_M1,"M5":mt5.TIMEFRAME_M5,"M15":mt5.TIMEFRAME_M15,
        "M30":mt5.TIMEFRAME_M30,"H1":mt5.TIMEFRAME_H1,"H4":mt5.TIMEFRAME_H4,
        "D1":mt5.TIMEFRAME_D1,"W1":mt5.TIMEFRAME_W1}

_gold_symbol = None   # resolved broker name

def resolve_gold():
    global _gold_symbol
    all_syms={s.name for s in (mt5.symbols_get() or [])}
    for v in config.GOLD_VARIANTS:
        if v in all_syms:
            info=mt5.symbol_info(v)
            if info and not info.visible: mt5.symbol_select(v,True)
            _gold_symbol=v; log.info(f"Gold symbol resolved: {v}"); return v
    log.error(f"Gold symbol not found! Tried: {config.GOLD_VARIANTS}")
    return None

def gold_sym():
    return _gold_symbol or resolve_gold()

def connect():
    if not mt5.initialize():
        log.error(f"MT5 init failed: {mt5.last_error()}"); return False
    if config.MT5_LOGIN:
        if not mt5.login(config.MT5_LOGIN,config.MT5_PASSWORD,config.MT5_SERVER):
            log.error(f"Login failed: {mt5.last_error()}"); mt5.shutdown(); return False
        log.info(f"Logged in #{config.MT5_LOGIN}")
    else:
        info=mt5.account_info()
        if info is None:
            log.error("No active MT5 session."); mt5.shutdown(); return False
        log.info(f"Active: #{info.login} @ {info.server}")
    resolve_gold()
    return True

def disconnect(): mt5.shutdown()
def is_connected(): return mt5.terminal_info() is not None
def reconnect(): disconnect(); return connect()

def account():
    i=mt5.account_info()
    if not i: return {}
    return {"login":i.login,"server":i.server,"balance":i.balance,
            "equity":i.equity,"margin":i.margin,"free_margin":i.margin_free,
            "leverage":i.leverage,"currency":i.currency,"profit":i.profit}

def get_ohlcv(tf:str, n:int=300) -> pd.DataFrame:
    sym=gold_sym()
    if not sym: return pd.DataFrame()
    rates=mt5.copy_rates_from_pos(sym,TF_MAP[tf.upper()],0,n)
    if rates is None or len(rates)==0: return pd.DataFrame()
    df=pd.DataFrame(rates)
    df["time"]=pd.to_datetime(df["time"],unit="s")
    return df[["time","open","high","low","close","tick_volume"]].rename(
        columns={"tick_volume":"volume"})

def get_tick():
    sym=gold_sym()
    if not sym: return {}
    t=mt5.symbol_info_tick(sym); i=mt5.symbol_info(sym)
    if not t or not i: return {}
    return {"bid":t.bid,"ask":t.ask,"spread_pts":round((t.ask-t.bid)/i.point),
            "point":i.point,"digits":i.digits,
            "time":datetime.fromtimestamp(t.time).strftime("%H:%M:%S")}

def symbol_info():
    sym=gold_sym()
    if not sym: return {}
    i=mt5.symbol_info(sym)
    if not i: return {}
    return {"digits":i.digits,"point":i.point,"min_lot":i.volume_min,
            "max_lot":i.volume_max,"lot_step":i.volume_step,
            "tick_value":i.trade_tick_value,"tick_size":i.trade_tick_size}

def get_positions():
    sym=gold_sym()
    if not sym: return []
    pos=mt5.positions_get(symbol=sym)
    if pos is None: return []
    return [{"ticket":p.ticket,"type":"BUY" if p.type==mt5.ORDER_TYPE_BUY else "SELL",
             "volume":p.volume,"price_open":p.price_open,"sl":p.sl,"tp":p.tp,
             "profit":p.profit,"magic":p.magic,"time":p.time} for p in pos]

def ds_positions():
    return [p for p in get_positions() if p["magic"]==config.MAGIC_NUMBER]

def count_ds(): return len(ds_positions())

def calc_lot(sl_distance:float, confidence:int) -> float:
    acct=account(); si=symbol_info()
    if not acct or not si or sl_distance<=0: return si.get("min_lot",0.01) if si else 0.01
    balance=acct["balance"]
    # Risk scale by confidence
    if confidence>=config.VERY_HIGH_CONFIDENCE:
        risk_pct=min(config.BASE_RISK_PCT*config.LOT_SCALE_HIGH, config.MAX_RISK_PCT)
    elif confidence>=config.HIGH_CONFIDENCE:
        risk_pct=min(config.BASE_RISK_PCT*config.LOT_SCALE_MID, config.MAX_RISK_PCT)
    else:
        risk_pct=config.BASE_RISK_PCT
    risk_amt=balance*risk_pct/100
    tv=si["tick_value"]; ts=si["tick_size"]
    if tv<=0 or ts<=0: return si["min_lot"]
    lot=risk_amt/((sl_distance/ts)*tv)
    step=si["lot_step"]
    lot=round(round(lot/step)*step,2)
    return max(si["min_lot"], min(lot, si["max_lot"]))

def place_order(direction:str, sl:float, tp:float,
                lot:float=None, confidence:int=70) -> dict:
    sym=gold_sym()
    if not sym: return {"success":False,"error":"No gold symbol"}
    tick=mt5.symbol_info_tick(sym); info=mt5.symbol_info(sym)
    if not tick or not info: return {"success":False,"error":"Tick unavailable"}
    spread=(tick.ask-tick.bid)/info.point
    if spread>config.MAX_SPREAD_POINTS:
        return {"success":False,"error":f"Spread {spread:.0f}pts too wide"}
    price=tick.ask if direction=="BUY" else tick.bid
    otype=mt5.ORDER_TYPE_BUY if direction=="BUY" else mt5.ORDER_TYPE_SELL
    sl_dist=abs(price-sl)
    if lot is None: lot=calc_lot(sl_dist, confidence)
    req={"action":mt5.TRADE_ACTION_DEAL,"symbol":sym,"volume":lot,
         "type":otype,"price":round(price,info.digits),
         "sl":round(sl,info.digits),"tp":round(tp,info.digits),
         "deviation":config.DEVIATION,"magic":config.MAGIC_NUMBER,
         "comment":config.COMMENT,"type_time":mt5.ORDER_TIME_GTC,
         "type_filling":mt5.ORDER_FILLING_IOC}
    res=mt5.order_send(req)
    if res is None or res.retcode!=mt5.TRADE_RETCODE_DONE:
        return {"success":False,"error":f"Retcode {res.retcode if res else 'N/A'}: {mt5.last_error()}"}
    return {"success":True,"ticket":res.order,"type":direction,
            "lot":lot,"price":res.price,"sl":sl,"tp":tp,"symbol":sym}

def modify_sl(ticket:int, new_sl:float) -> bool:
    pos=mt5.positions_get(ticket=ticket)
    if not pos: return False
    p=pos[0]; info=mt5.symbol_info(p.symbol)
    req={"action":mt5.TRADE_ACTION_SLTP,"symbol":p.symbol,"position":ticket,
         "sl":round(new_sl,info.digits if info else 5),"tp":p.tp}
    res=mt5.order_send(req)
    return res is not None and res.retcode==mt5.TRADE_RETCODE_DONE

def partial_close(ticket:int, close_pct:float=0.5) -> dict:
    pos=mt5.positions_get(ticket=ticket)
    if not pos: return {"success":False,"error":"Not found"}
    p=pos[0]; si=mt5.symbol_info(p.symbol); tick=mt5.symbol_info_tick(p.symbol)
    close_vol=round(p.volume*close_pct/si.volume_step)*si.volume_step
    close_vol=max(si.volume_min, min(close_vol, p.volume))
    ctype=mt5.ORDER_TYPE_SELL if p.type==mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY
    cprice=tick.bid if p.type==mt5.ORDER_TYPE_BUY else tick.ask
    req={"action":mt5.TRADE_ACTION_DEAL,"symbol":p.symbol,"volume":close_vol,
         "type":ctype,"position":ticket,"price":cprice,"deviation":20,
         "magic":config.MAGIC_NUMBER,"comment":"DS-Partial",
         "type_time":mt5.ORDER_TIME_GTC,"type_filling":mt5.ORDER_FILLING_IOC}
    res=mt5.order_send(req)
    ok=res and res.retcode==mt5.TRADE_RETCODE_DONE
    return {"success":ok,"ticket":ticket,"closed_vol":close_vol,
            "error":"" if ok else f"Retcode {res.retcode if res else 'N/A'}"}

def close_position(ticket:int) -> dict:
    pos=mt5.positions_get(ticket=ticket)
    if not pos: return {"success":False,"error":"Not found"}
    p=pos[0]; tick=mt5.symbol_info_tick(p.symbol)
    ctype=mt5.ORDER_TYPE_SELL if p.type==mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY
    cprice=tick.bid if p.type==mt5.ORDER_TYPE_BUY else tick.ask
    req={"action":mt5.TRADE_ACTION_DEAL,"symbol":p.symbol,"volume":p.volume,
         "type":ctype,"position":ticket,"price":cprice,"deviation":20,
         "magic":config.MAGIC_NUMBER,"comment":"DS-Close",
         "type_time":mt5.ORDER_TIME_GTC,"type_filling":mt5.ORDER_FILLING_IOC}
    res=mt5.order_send(req)
    ok=res and res.retcode==mt5.TRADE_RETCODE_DONE
    return {"success":ok,"ticket":ticket,"profit":p.profit,
            "error":"" if ok else f"Retcode {res.retcode if res else 'N/A'}"}

def get_closed_trades(n:int=30) -> list[dict]:
    from_t=datetime.now()-timedelta(days=30)
    deals=mt5.history_deals_get(from_t,datetime.now())
    if not deals: return []
    result=[]
    for d in deals:
        if d.magic==config.MAGIC_NUMBER and d.entry==mt5.DEAL_ENTRY_OUT:
            result.append({"ticket":d.order,"type":"BUY" if d.type==mt5.DEAL_TYPE_BUY else "SELL",
                           "price":d.price,"profit":d.profit,"symbol":d.symbol,
                           "time":datetime.fromtimestamp(d.time).isoformat()})
    return result[-n:]
