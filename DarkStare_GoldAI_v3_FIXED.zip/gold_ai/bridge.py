"""
bridge.py — DarkStare Gold AI v3 | 24/7 | Self-Learning | EAT Sessions
XAUUSD Master | Profit Protection | Trailing Stops | Re-entries | Account Monitor

Usage:
    python bridge.py                   # full auto-trade
    python bridge.py --analysis-only   # signals only, no orders
"""

import sys, time, json, logging, argparse, threading
from datetime import datetime
from pathlib import Path

import config
import sessions
import mt5_connector as mt5c
import gold_indicators
import gold_patterns
import gold_ai_engine as engine
import gold_brain as brain

# ─── LOGGING ──────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(config.LOG_FILE, encoding="utf-8"),
    ]
)
log = logging.getLogger("GoldAI")

BANNER = """
  ██████╗  ██████╗ ██╗     ██████╗      █████╗ ██╗
 ██╔════╝ ██╔═══██╗██║     ██╔══██╗    ██╔══██╗██║
 ██║  ███╗██║   ██║██║     ██║  ██║    ███████║██║
 ██║   ██║██║   ██║██║     ██║  ██║    ██╔══██║██║
 ╚██████╔╝╚██████╔╝███████╗██████╔╝    ██║  ██║██║
  ╚═════╝  ╚═════╝ ╚══════╝╚═════╝     ╚═╝  ╚═╝╚═╝
  DARKSTARE GOLD AI v3  |  XAUUSD MASTER  |  24/7 EAT
  Self-Learning | Pattern Discovery | Profit Protection
"""

# ─── GLOBAL STATE ─────────────────────────────────────────────
_running         = True
_last_scan       = 0.0
_known_tickets   = set()
_ticket_tokens   = {}       # ticket → market tokens for learning
_ticket_data     = {}       # ticket → {direction, entry, sl, tp, lot, partial_done}
_peak_equity     = 0.0      # for drawdown kill switch
_reentry_wait    = {}       # symbol → last close time (re-entry cooldown)
_partial_done    = set()    # tickets where partial close already executed


# ─── HELPERS ──────────────────────────────────────────────────
def _ds_pos():      return mt5c.ds_positions()
def _count_ds():    return mt5c.count_ds()

def _save_trade(decision, result):
    path = Path(config.TRADES_LOG); data = []
    if path.exists():
        try: data = json.loads(path.read_text())
        except: pass
    data.append({"ts": datetime.now().isoformat(),
                 "decision": {k: v for k, v in decision.items() if k != "tokens"},
                 "result": result})
    path.write_text(json.dumps(data, indent=2))

def _rotate_log():
    path = Path(config.LOG_FILE)
    if not path.exists(): return
    lines = path.read_text(encoding="utf-8").splitlines()
    if len(lines) > config.MAX_LOG_LINES:
        path.write_text("\n".join(lines[-int(config.MAX_LOG_LINES*0.8):]),
                        encoding="utf-8")


# ─── CLOSED TRADE DETECTOR ────────────────────────────────────
def _detect_closed():
    global _known_tickets
    current = {p["ticket"] for p in _ds_pos()}
    closed  = _known_tickets - current
    for ticket in closed:
        for ct in mt5c.get_closed_trades(50):
            if ct["ticket"] == ticket:
                pnl    = ct["profit"]
                toks   = _ticket_tokens.pop(ticket, [])
                result = brain.record_close(ticket, ct["price"], pnl, toks)
                emoji  = "✅ WIN" if pnl > 0 else ("⚠ BE" if pnl == 0 else "❌ LOSS")
                log.info(f"  Trade #{ticket} CLOSED: {emoji}  PnL: ${pnl:.2f}")
                log.info(f"  🧠 {brain.mem_stats()}")
                log.info(f"  📊 {brain.seq_stats()}")
                log.info(f"  🔬 {brain.strat_stats()}")
                # Log outcome to strategy discovery
                try:
                    td = _ticket_data.pop(ticket, {})
                    brain.record_obs(toks, td.get("direction","BUY"),
                                     sessions.current_key(), 0,
                                     td.get("rr", 0),
                                     outcome="WIN" if pnl>0 else "LOSS",
                                     pnl=pnl)
                except Exception:
                    pass
                _partial_done.discard(ticket)
                _reentry_wait[config.GOLD_VARIANTS[0]] = time.time()
                break
    _known_tickets = current


# ─── ACCOUNT MONITORING ───────────────────────────────────────
def _check_account_health(acct: dict) -> tuple[bool, str]:
    """
    Monitor account health:
    - Drawdown kill switch: if equity drops X% from peak → stop all trading
    - Profit lock: if floating profit is good, tighten trailing stops
    Returns (can_trade, reason)
    """
    global _peak_equity
    equity = acct.get("equity", 0)
    balance= acct.get("balance", 1)

    if equity > _peak_equity:
        _peak_equity = equity

    # Drawdown check
    if _peak_equity > 0:
        dd_pct = (_peak_equity - equity) / _peak_equity * 100
        if dd_pct >= config.DRAWDOWN_KILL_PCT:
            return False, (f"🛑 DRAWDOWN KILL: Equity dropped {dd_pct:.1f}% "
                          f"from peak ${_peak_equity:.2f} → stop trading")

    # Floating profit check
    profit = acct.get("profit", 0)
    if profit > 0:
        profit_pct = profit / balance * 100
        return True, f"✅ Floating profit: ${profit:.2f} (+{profit_pct:.1f}%)"

    return True, ""


def _account_summary(acct: dict) -> str:
    bal = acct.get("balance", 0); eq = acct.get("equity", 0)
    pr  = acct.get("profit", 0);  fm = acct.get("free_margin", 0)
    pnl_today = brain.load_mem().get("total_pnl", 0)
    return (f"Bal:${bal:.2f} Eq:${eq:.2f} Float:${pr:+.2f} "
            f"FreeMgn:${fm:.2f} | AllTimePnL:${pnl_today:.2f}")


# ─── TRAILING STOP + PROFIT PROTECTION ────────────────────────
def _manage_trade(pos: dict, current_price: float, atr: float):
    """
    For one open position:
    1. Move to breakeven at TRAIL_ACTIVATE_RR
    2. Partial close at PARTIAL_CLOSE_RR
    3. Active trailing stop at TRAIL_ATR_MULT × ATR
    4. Profit lock — if floating profit ≥ PROFIT_LOCK_RR × risk → lock % of profit
    """
    ticket = pos["ticket"]
    dtype  = pos["type"]
    entry  = pos["price_open"]
    sl     = pos["sl"]
    tp     = pos["tp"]
    lot    = pos["volume"]

    if entry <= 0: return

    sl_dist = abs(entry - sl) if sl > 0 else atr * config.ATR_SL_MULT
    tp_dist = abs(entry - tp) if tp > 0 else atr * config.ATR_TP_MULT
    trail_dist = atr * config.TRAIL_ATR_MULT

    # Current profit distance
    if dtype == "BUY":
        profit_dist = current_price - entry
        be_sl       = entry + 0.01        # 1 pip above entry
        trail_sl    = current_price - trail_dist
        be_triggered= profit_dist >= sl_dist * config.TRAIL_ACTIVATE_RR
        lock_sl     = entry + profit_dist * config.PROFIT_LOCK_PCT
    else:
        profit_dist = entry - current_price
        be_sl       = entry - 0.01
        trail_sl    = current_price + trail_dist
        be_triggered= profit_dist >= sl_dist * config.TRAIL_ACTIVATE_RR
        lock_sl     = entry - profit_dist * config.PROFIT_LOCK_PCT

    # ── Breakeven ────────────────────────────────────
    if config.BREAKEVEN_ENABLE and be_triggered:
        if dtype == "BUY"  and sl < be_sl:
            if mt5c.modify_sl(ticket, be_sl):
                log.info(f"  ⚡ BE #{ticket}: SL → {be_sl:.3f}")
        elif dtype == "SELL" and sl > be_sl:
            if mt5c.modify_sl(ticket, be_sl):
                log.info(f"  ⚡ BE #{ticket}: SL → {be_sl:.3f}")

    # ── Partial Close ────────────────────────────────
    if config.PARTIAL_CLOSE_ENABLE and ticket not in _partial_done:
        partial_rr = profit_dist / sl_dist if sl_dist > 0 else 0
        if partial_rr >= config.PARTIAL_CLOSE_RR:
            res = mt5c.partial_close(ticket, config.PARTIAL_CLOSE_PCT)
            if res.get("success"):
                _partial_done.add(ticket)
                log.info(f"  ✂ PARTIAL CLOSE #{ticket}: "
                         f"closed {config.PARTIAL_CLOSE_PCT*100:.0f}% "
                         f"at {current_price:.3f} (RR:{partial_rr:.2f})")

    # ── Profit Lock ──────────────────────────────────
    if config.PROFIT_PROTECT_ENABLE:
        lock_rr = profit_dist / sl_dist if sl_dist > 0 else 0
        if lock_rr >= config.PROFIT_LOCK_RR:
            if dtype == "BUY"  and lock_sl > sl:
                if mt5c.modify_sl(ticket, lock_sl):
                    log.info(f"  🔒 PROFIT LOCK #{ticket}: SL → {lock_sl:.3f}")
            elif dtype == "SELL" and lock_sl < sl:
                if mt5c.modify_sl(ticket, lock_sl):
                    log.info(f"  🔒 PROFIT LOCK #{ticket}: SL → {lock_sl:.3f}")

    # ── Active Trailing ──────────────────────────────
    if config.TRAIL_ENABLE and be_triggered:
        if dtype == "BUY"  and trail_sl > sl + 0.005:
            if mt5c.modify_sl(ticket, round(trail_sl, 3)):
                log.info(f"  🔄 TRAIL #{ticket}: SL {sl:.3f}→{trail_sl:.3f}")
        elif dtype == "SELL" and trail_sl < sl - 0.005:
            if mt5c.modify_sl(ticket, round(trail_sl, 3)):
                log.info(f"  🔄 TRAIL #{ticket}: SL {sl:.3f}→{trail_sl:.3f}")


def _trailing_loop():
    """Dedicated fast thread for trailing stops — runs every TRAIL_INTERVAL seconds."""
    while _running:
        try:
            if mt5c.is_connected():
                tick = mt5c.get_tick()
                if tick:
                    mid = (tick["bid"] + tick["ask"]) / 2
                    # Get ATR from M15
                    df15 = mt5c.get_ohlcv("M15", 30)
                    if not df15.empty:
                        tr  = (df15["high"] - df15["low"]).rolling(14).mean()
                        atr = float(tr.iloc[-1]) if not tr.empty else 1.0
                    else:
                        atr = 1.0
                    for pos in _ds_pos():
                        _manage_trade(pos, mid, atr)
        except Exception as e:
            log.debug(f"Trail error: {e}")
        time.sleep(config.TRAIL_INTERVAL)


# ─── RE-ENTRY LOGIC ───────────────────────────────────────────
def _check_reentry(decision: dict, last_close_time: float) -> bool:
    """Allow re-entry if enough time has passed and conditions are still valid."""
    if not config.REENTRY_ENABLE:
        return False
    elapsed = time.time() - last_close_time
    min_wait = config.REENTRY_MIN_BARS * 15 * 60  # bars × 15min
    if elapsed < min_wait:
        return False
    return decision["confidence"] >= int(config.REENTRY_CONDITION * 100)


# ─── ANALYSIS SCAN ────────────────────────────────────────────
def _scan_gold(auto_trade: bool):
    """Full multi-timeframe gold analysis and trade execution."""

    # Collect data on ALL timeframes
    tf_indicators = {}
    tf_patterns   = {}
    primary_tokens= []

    for tf in config.TIMEFRAMES:
        df = mt5c.get_ohlcv(tf, config.CANDLES)
        if df.empty:
            log.warning(f"  No data {tf} — skip")
            continue

        ind = gold_indicators.calc(df)
        tf_indicators[tf] = ind

        pat = gold_patterns.detect_all(df, ind)
        tf_patterns[tf]   = pat

        # Tokenize primary TF for learning
        if tf == config.PRIMARY_TF:
            ind_dict = gold_indicators.to_dict(ind)
            top_pat  = pat.get("top","none")
            struct   = "BULL" if (ind.hh and ind.hl) else ("BEAR" if (ind.lh and ind.ll) else "NEUTRAL")
            primary_tokens = brain.tokenize(ind_dict, sessions.current_key(),
                                            top_pat, struct)

    if not tf_indicators:
        log.error("  No gold data on any timeframe!")
        return

    # Run AI engine
    decision = engine.analyse(tf_indicators, tf_patterns, primary_tokens)
    tick      = mt5c.get_tick()

    # ── Display full analysis ─────────────────────────────────
    sep = "─" * 62
    log.info(f"\n{sep}")
    log.info(f"  GOLD (XAU/USD) | {tick.get('bid',0):.3f} / {tick.get('ask',0):.3f}"
             f" | Spread: {tick.get('spread_pts','?')} pts")
    log.info(f"  {sessions.summary()}")
    log.info(sep)

    # Per-timeframe MA summary
    for tf in ["M5","M15","H1","H4","D1"]:
        if tf not in tf_indicators: continue
        ind = tf_indicators[tf]
        log.info(f"  [{tf:3s}] Trend:{ind.ma_trend:7s} | "
                 f"EMA9:{ind.ema9:.2f} EMA21:{ind.ema21:.2f} "
                 f"EMA50:{ind.ema50:.2f} EMA200:{ind.ema200:.2f} | "
                 f"RSI:{ind.rsi:.1f}")

    log.info(sep)

    # Primary TF patterns
    pats = tf_patterns.get(config.PRIMARY_TF, {})
    if pats.get("notes"):
        log.info("  📐 PATTERNS:")
        for note in pats["notes"][:5]:
            log.info(f"    • {note}")
    if pats.get("trap_detected"):
        log.info("  ⚠  MARKET TRAP DETECTED — extra caution!")

    log.info(sep)
    log.info(f"  DECISION: {decision['action']:5s} | "
             f"Bias: {decision['bias']:8s} | "
             f"Confidence: {decision['confidence']}%")
    log.info(f"  Entry: {decision['entry']:.3f} | "
             f"SL: {decision['sl']:.3f} | "
             f"TP: {decision['tp']:.3f} | "
             f"RR: {decision['rr']}")
    log.info("  Reasons:")
    for r in decision["reasons"][:8]:
        log.info(f"    → {r}")
    log.info(sep)

    if not auto_trade:
        return

    # ── Trade execution ───────────────────────────────────────
    action = decision["action"]
    conf   = decision["confidence"]

    if action == "HOLD":
        log.info("  HOLD — waiting for higher confidence setup")
        return

    # Check account health
    acct = mt5c.account()
    can_trade_acct, acct_reason = _check_account_health(acct)
    if not can_trade_acct:
        log.warning(f"  {acct_reason}")
        return

    # Check if already in a trade in same direction
    existing = _ds_pos()
    same_dir = [p for p in existing if p["type"] == action]

    # Check for re-entry opportunity
    sym_key = "XAUUSD"
    last_close = _reentry_wait.get(sym_key, 0)
    is_reentry = last_close > 0

    if same_dir:
        # Already have a trade this direction
        if not is_reentry or not _check_reentry(decision, last_close):
            log.info(f"  Already in {action} — waiting for re-entry conditions")
            return
        else:
            log.info(f"  🔄 RE-ENTRY signal confirmed (conf:{conf}%)")

    if _count_ds() >= config.MAX_OPEN_TRADES:
        log.info(f"  Max positions ({config.MAX_OPEN_TRADES}) reached — skip")
        return

    # ── Place order ───────────────────────────────────────────
    lot_scale = config.REENTRY_LOT_SCALE if is_reentry else 1.0
    log.info(f"  >>> PLACING {action} | Conf:{conf}% | "
             f"SL:{decision['sl']:.3f} TP:{decision['tp']:.3f}")

    result = mt5c.place_order(
        action, decision["sl"], decision["tp"], confidence=conf)

    if result.get("success"):
        ticket = result["ticket"]
        log.info(f"  ✅ ORDER PLACED! Ticket #{ticket} | "
                 f"{result['lot']} lots @ {result['price']:.3f}")

        # Register in tracking
        _known_tickets.add(ticket)
        _ticket_tokens[ticket]  = primary_tokens
        _ticket_data[ticket]    = {
            "direction": action,
            "entry":     result["price"],
            "sl":        result["sl"],
            "tp":        result["tp"],
            "lot":       result["lot"],
            "rr":        decision["rr"],
        }

        # Record in brain
        brain.record_open(
            ticket, action, result["price"],
            result["sl"], result["tp"], result["lot"],
            conf, decision["active_strats"],
            pats.get("top","none"), sessions.current_key())
        brain.record_obs(primary_tokens, action,
                         sessions.current_key(), conf, decision["rr"])
        _reentry_wait.pop(sym_key, None)  # reset re-entry timer
        _save_trade(decision, result)

    else:
        log.error(f"  ❌ ORDER FAILED: {result.get('error','Unknown error')}")


# ─── WATCHDOG ─────────────────────────────────────────────────
def _watchdog():
    while _running:
        time.sleep(config.WATCHDOG_INTERVAL)
        stale = time.time() - _last_scan
        if _last_scan > 0 and stale > config.SCAN_INTERVAL * 5:
            log.warning(f"⚠ WATCHDOG: No scan in {stale:.0f}s!")


# ─── MAIN SCAN LOOP ───────────────────────────────────────────
def _scan_loop(auto_trade: bool):
    global _running, _last_scan, _known_tickets, _peak_equity

    # Init equity peak
    acct = mt5c.account()
    _peak_equity = acct.get("equity", 0)
    _known_tickets = {p["ticket"] for p in _ds_pos()}

    log.info("Gold AI scan loop running 24/7 ...")
    scan_num = 0

    while _running:
        try:
            # Reconnect if needed
            if not mt5c.is_connected():
                log.warning("MT5 disconnected — reconnecting ...")
                if not mt5c.reconnect():
                    log.error("Reconnect failed. Retry in 30s ...")
                    time.sleep(30); continue
                log.info("Reconnected ✓")

            t0 = time.time()
            scan_num += 1

            log.info(f"\n{'═'*62}")
            log.info(f"  GOLD AI SCAN #{scan_num} | "
                     f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            log.info(f"  {sessions.summary()}")

            # Account status
            acct  = mt5c.account()
            can_t, health_note = _check_account_health(acct)
            log.info(f"  💰 {_account_summary(acct)}")
            if health_note:
                log.info(f"  {health_note}")
            log.info(f"  📍 Open gold positions: {_count_ds()}/{config.MAX_OPEN_TRADES}")
            log.info(f"  🧠 {brain.mem_stats()}")
            log.info(f"  📊 {brain.seq_stats()}")
            log.info(f"  🔬 {brain.strat_stats()}")
            log.info(f"{'═'*62}")

            # Check for closed trades → triggers learning
            _detect_closed()

            # Run analysis
            try:
                _scan_gold(auto_trade and can_t)
            except Exception as e:
                log.error(f"Analysis error: {e}", exc_info=True)

            elapsed    = time.time() - t0
            _last_scan = time.time()
            sleep_sec  = max(0, config.SCAN_INTERVAL - elapsed)
            log.info(f"  Scan #{scan_num} done in {elapsed:.1f}s → next in {sleep_sec:.0f}s")
            _rotate_log()
            time.sleep(sleep_sec)

        except Exception as e:
            log.error(f"Scan loop error: {e}", exc_info=True)
            time.sleep(15)


# ─── MAIN ─────────────────────────────────────────────────────
def main():
    global _running
    print(BANNER)

    parser = argparse.ArgumentParser(description="DarkStare Gold AI v3")
    parser.add_argument("--analysis-only", action="store_true",
                        help="Signals only — no orders placed")
    args = parser.parse_args()

    auto_trade = config.AUTO_TRADE and not args.analysis_only

    log.info("Connecting to MetaTrader 5 ...")
    if not mt5c.connect():
        log.error("MT5 connection failed. Is MT5 open and logged in?")
        sys.exit(1)

    acct = mt5c.account()
    sym  = mt5c.gold_sym()
    log.info(f"Account #{acct.get('login')} @ {acct.get('server')}")
    log.info(f"Balance: ${acct.get('balance',0):.2f} {acct.get('currency','')} | "
             f"Leverage: 1:{acct.get('leverage',0)}")
    log.info(f"Gold symbol: {sym}")
    log.info(f"Auto-trade: {'ON ✅' if auto_trade else 'OFF (analysis only)'}")
    log.info(f"Timeframes: {', '.join(config.TIMEFRAMES)}")
    log.info(f"Scan: every {config.SCAN_INTERVAL}s | Trail: every {config.TRAIL_INTERVAL}s")
    log.info(f"Risk: base {config.BASE_RISK_PCT}% | max {config.MAX_RISK_PCT}%")
    log.info(f"Spread limit: {config.MAX_SPREAD_POINTS}pts (very permissive for gold)")
    log.info(f"Memory: {brain.mem_stats()}\n")

    # Launch support threads
    for fn, name in [(_trailing_loop,"Trail"), (_watchdog,"Watchdog")]:
        t = threading.Thread(target=fn, daemon=True, name=name)
        t.start()
        log.info(f"  Thread started: {name}")

    try:
        _scan_loop(auto_trade)
    except KeyboardInterrupt:
        log.info("\n⛔ Stopped by user (Ctrl+C)")
        _running = False
    finally:
        mt5c.disconnect()
        log.info("Gold AI shut down. Goodbye.")


if __name__ == "__main__":
    main()
