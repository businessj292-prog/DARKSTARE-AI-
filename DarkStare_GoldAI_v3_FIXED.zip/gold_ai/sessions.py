"""sessions.py — EAT (UTC+3) session detection for Gold AI."""
from datetime import datetime, timezone, timedelta
import config

EAT = timezone(timedelta(hours=3))

def now_eat() -> datetime:
    return datetime.now(EAT)

def get_active_sessions() -> list[dict]:
    hour = now_eat().hour
    active = []
    for key, (start, end, label, mult) in config.EAT_SESSIONS.items():
        in_sess = (hour >= start or hour < end) if start > end else (start <= hour < end)
        if in_sess:
            active.append({"key":key,"label":label,"mult":mult,
                            "tradeable":key in config.TRADE_SESSIONS})
    return active

def is_tradeable() -> tuple[bool, str]:
    for s in get_active_sessions():
        if s["tradeable"]: return True, s["label"]
    ss = get_active_sessions()
    return False, (ss[0]["label"] if ss else "No session")

def multiplier() -> float:
    ss = get_active_sessions()
    return max((s["mult"] for s in ss), default=0.5)

def current_key() -> str:
    ss = get_active_sessions()
    for k in ["overlap","london","newyork","asian","dead"]:
        if any(s["key"]==k for s in ss): return k
    return "unknown"

def is_gold_killzone() -> bool:
    h = now_eat().hour
    return config.GOLD_KILLZONE[0] <= h < config.GOLD_KILLZONE[1]

def summary() -> str:
    now = now_eat()
    ss  = get_active_sessions()
    can, reason = is_tradeable()
    kz  = " 🔥KILLZONE" if is_gold_killzone() else ""
    labels = ", ".join(s["label"] for s in ss) if ss else "None"
    return f"[EAT {now.strftime('%H:%M')}] {labels}{kz} | {'✅' if can else '🚫'} {reason}"
